# AutoCAD Helper (by EVLab)

একটি প্লাগইন — একবার লোড করলেই ক্যাটাগরি অনুযায়ী সাজানো **২৪টি টুল** ব্যবহার করা যাবে।
One plugin, install once — get **24 tools** organized into 4 categories.

---

## 📥 Install (কিভাবে ইন্সটল করবেন)

1. `AutoCAD_Helper.lsp` ফাইলটি ডাউনলোড করুন।
2. AutoCAD ওপেন করুন এবং কমান্ড লাইনে টাইপ করুন: `APPLOAD`
3. `AutoCAD_Helper.lsp` ফাইলটি সিলেক্ট করে **Load** করুন।
4. প্রতিবার AutoCAD চালু হলে স্বয়ংক্রিয়ভাবে লোড করতে চাইলে, APPLOAD উইন্ডোতে **Startup Suite**-এ ফাইলটি যোগ করে দিন (একবার করলেই হবে)।
5. কমান্ড লাইনে টাইপ করুন `AH` — পুরো কমান্ড লিস্ট ক্যাটাগরি অনুযায়ী দেখতে পাবেন।

### Quick install
1. Download `AutoCAD_Helper.lsp`
2. In AutoCAD, run `APPLOAD` → select the file → **Load**
3. (Optional, recommended) Add it to **Startup Suite** in the same APPLOAD dialog so it loads automatically every session.
4. Type `AH` anytime to see the full categorized command list.

---

## 🧰 Command List by Category

### 1️⃣ Survey & Point Tools (সার্ভে ও পয়েন্ট টুলস)
| Command | কাজ (Description) |
|---|---|
| `FPOINT` | নির্দিষ্ট পয়েন্টে ডোনাট (survey marker) তৈরি করে, ডায়ামিটার সেট করা যায়। |
| `FPSTYLE` | পয়েন্ট স্টাইলকে ফিল্ড সার্কেল (গোল পয়েন্ট) এ পরিবর্তন করে। |
| `PFILL` | সিলেক্ট করা POINT গুলোকে রঙ ও ফিল্ড-সার্কেল স্টাইলে (survey marker) পরিণত করে। |
| `PCT` | সিলেক্ট করা POINT গুলোর জায়গায় টেক্সট (RL/Chainage ইত্যাদি) বসায়। |
| `PTB` | সিলেক্ট করা POINT গুলোতে নির্দিষ্ট ব্লক ইনসার্ট করে (স্ট্যাটাস রিপোর্টসহ)। |
| `PTBL` | সিলেক্ট করা POINT গুলোতে নির্দিষ্ট ব্লক দ্রুত ইনসার্ট করে (no dialog)। |

### 2️⃣ Text & Annotation Tools (টেক্সট ও অ্যানোটেশন টুলস)
| Command | কাজ (Description) |
|---|---|
| `T110` | সিলেক্ট করা টেক্সট/এম-টেক্সটকে "110" এ পরিবর্তন করে। |
| `CH110` | সিলেকশন সেটের সব টেক্সট থেকে "90" খুঁজে "110" এ পরিবর্তন করে। |
| `UL` | সিলেক্ট করা টেক্সট/এম-টেক্সটকে আন্ডারলাইন করে। |
| `JTO` | দুইটি টেক্সটের মান নিয়ে মাঝে "to" লিখে আন্ডারলাইনসহ নতুন টেক্সট তৈরি করে। |
| `LPEP` | সিলেক্ট করা সব সার্কেলের ভেতরে নির্দিষ্ট টেক্সট বসিয়ে দেয়। |

### 3️⃣ Layer Tools (লেয়ার টুলস)
| Command | কাজ (Description) |
|---|---|
| `SDLW` | সিলেকশনের লেয়ার তালিকা দেখায় এবং পছন্দমতো লেয়ার আলাদাভাবে সিলেক্ট করতে দেয়। |

### 4️⃣ Layout & Sheet Management Tools (লেআউট ও শীট ম্যানেজমেন্ট টুলস)
| Command | কাজ (Description) |
|---|---|
| `ACAD` | Model বাদে সব লেআউটকে "DWG To PDF.pc3" + "acad.ctb" প্লট স্টাইলে সেট করে। |
| `CTBACA` | সব লেআউটকে (Model সহ) "DWG To PDF.pc3" + "acad.ctb" প্লট স্টাইলে সেট করে। |
| `CLRLAYTXT` | সব লেআউট থেকে টেক্সট/এম-টেক্সট মুছে ফেলে (ব্লকের ভিতরের টেক্সট বাদে)। |
| `FFFVPFIND` | নির্দিষ্ট টেক্সট খুঁজে বের করে জুম করে ও সিলেক্ট করে দেয়। |
| `LAYREN` | লেআউটগুলোকে নির্দিষ্ট প্রিফিক্স ও সিরিয়াল নম্বর দিয়ে রিনেম করে। |
| `LAYSORTNUM` | লেআউটের নামের নম্বর অনুযায়ী ট্যাব অর্ডার সাজিয়ে দেয়। |
| `NEXTLAY` | পরবর্তী লেআউটে সুইচ করে (শেষে থাকলে প্রথমে ফিরে আসে)। |
| `NSYNC` | নর্থ সাইন ব্লককে ভিউপোর্টের টুইস্ট অ্যাঙ্গেল অনুযায়ী ঘোরায়। |
| `SSSCOPY` | কারেন্ট লেআউট (যেমন (01)) কপি করে পরের সিরিয়াল নম্বরসহ নতুন লেআউট তৈরি করে। |
| `SHNO` | কারেন্ট লেআউট নাম অনুযায়ী ডাইনামিক শিট নম্বর টেক্সট (ফিল্ড) তৈরি করে। |
| `SNO-DRWNO` | শিট সিরিয়াল + ড্রয়িং নম্বর একসাথে বসিয়ে দেয়। |
| `VPLOCKALL` | সব লেআউটের ভিউপোর্ট একসাথে লক/আনলক করে। |

---

## ℹ️ Notes
- `AH` বা `AUTOCADHELPER` টাইপ করলে যেকোনো সময় উপরের পুরো লিস্ট কমান্ড লাইনে দেখা যাবে।
- `ACAD` এবং `CTBACA` — দুটোই প্রায় একই কাজ করে (plot style সেট করা); `CTBACA` Model ট্যাবসহ সব লেআউটে কাজ করে, `ACAD` শুধু paper layout গুলোতে।
- এই প্লাগইনটি AutoCAD 2018+ এবং Civil 3D-তে কাজ করবে (standard AutoLISP + ActiveX, কোনো external dependency নেই)।
- ভবিষ্যতে নতুন ক্যাটাগরি বা টুল যোগ হলে এই একই প্লাগইন আপডেট করে আবার শুধু `AutoCAD_Helper.lsp` রিলোড করলেই নতুন কমান্ডগুলো পাওয়া যাবে।

Works on AutoCAD 2018+ and Civil 3D. Pure AutoLISP + ActiveX, no external dependencies.
