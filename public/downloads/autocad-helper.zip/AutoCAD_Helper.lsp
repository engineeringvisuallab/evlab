;;; ============================================================
;;;   AUTOCAD HELPER  --  by EVLab
;;;   একটি প্লাগইন, ক্যাটাগরি অনুযায়ী সাজানো একাধিক টুল
;;;   One plugin, multiple category-wise organized tools
;;; ============================================================
;;;
;;;   Categories included in this file:
;;;     - সার্ভে ও পয়েন্ট টুলস (Survey & Point Tools)
;;;     - টেক্সট ও অ্যানোটেশন টুলস (Text & Annotation Tools)
;;;     - লেয়ার টুলস (Layer Tools)
;;;     - লেআউট ও শীট ম্যানেজমেন্ট টুলস (Layout & Sheet Management Tools)
;;;
;;;   Type  AH  or  AUTOCADHELPER  anytime to see the full command list.
;;; ============================================================


;; ================================================================
;; CATEGORY: সার্ভে ও পয়েন্ট টুলস (Survey & Point Tools)
;; ================================================================

;; ---- FPOINT : নির্দিষ্ট পয়েন্টে ডোনাট (survey marker) তৈরি করে, ডায়ামিটার সেট করা যায়।
;; (source: Fpoint.lsp)
(defun c:FPOINT (/ p d)
  (setq p (getpoint "\nSelect Point Location: "))
  (setq d (getreal "\nEnter Diameter <1>: "))
  (if (null d) (setq d 1.0))

  (command "_.DONUT" "0" d p "")
  (princ)
)

;; ---- FPSTYLE : পয়েন্ট স্টাইলকে ফিল্ড সার্কেল (গোল পয়েন্ট) এ পরিবর্তন করে।
;; (source: fpstyle.lsp)
(defun c:FPSTYLE ( / )
  (setvar "PDMODE" 35)
  (setvar "PDSIZE" 5)
  (command "_.REGEN")
  (princ "\nPoint style changed to filled circle.")
  (princ)
)

;; ---- PFILL : সিলেক্ট করা POINT গুলোকে রঙ ও ফিল্ড-সার্কেল স্টাইলে (survey marker) পরিণত করে।
;; (source: PFILL.lsp)
(defun c:PFILL (/ ss i ent)
  (setq ss (ssget '((0 . "POINT"))))
  (if ss
    (progn
      (setq i 0)
      (repeat (sslength ss)
        (setq ent (ssname ss i))
        (entmod
          (append (entget ent)
            '((62 . 1))
          )
        )
        (setq i (1+ i))
      )
      (setvar "PDMODE" 35)
      (setvar "PDSIZE" 5)
      (princ "\nPoint fill completed.")
    )
    (princ "\nNo point selected.")
  )
  (princ)
)

;; ---- PCT : সিলেক্ট করা POINT গুলোর জায়গায় (RL/Chainage ইত্যাদি) টেক্সট বসায়।
;; (source: PCT.lsp)
(defun c:PCT ( / ss i ent pt txt ht)

  ;; ইউজার থেকে টেক্সট নেবে
  (setq txt (getstring T "\nEnter text for point circles: "))

  ;; text height
  (setq ht 0.3)

  ;; POINT select করবে
  (setq ss (ssget '((0 . "POINT"))))

  (if ss
    (progn
      (setq i 0)
      (repeat (sslength ss)

        (setq ent (ssname ss i))
        (setq pt (cdr (assoc 10 (entget ent)))) ;; point coordinate

        ;; সেই point এ text বসাবে (circle marker ধরেই)
        (entmake
          (list
            (cons 0 "TEXT")
            (cons 10 pt)
            (cons 40 ht)
            (cons 1 txt)
            (cons 7 "STANDARD")
            (cons 72 1)
            (cons 73 2)
            (cons 11 pt)
          )
        )

        (setq i (1+ i))
      )
    )
  )

  (princ "\nText placed on point circles.")
  (princ)
)

;; ---- PTB : সিলেক্ট করা POINT গুলোর জায়গায় নির্দিষ্ট ব্লক ইনসার্ট করে (ডায়ালগসহ, রিপোর্টসহ)।
;; (source: PointToBlock PTB.lsp)
;;; PointToBlock.lsp
;;; Command: PTB - Inserts blocks at selected point locations
;;; Compatible with AutoCAD 2021 and later
;;; Author: AutoLISP Developer
;;; Date: 2026

(defun c:PTB ( / *error* ss blockName blockObj insertCount pt ptList i)
  
  ;; Local error handler
  (defun *error* (msg)
    (cond
      ((not msg)) ; Normal exit
      ((member msg '("Function cancelled" "quit / exit abort")))
      (t (princ (strcat "\nError: " msg)))
    )
    (princ)
  )

  ;; Main program
  (princ "\nPoint To Block - Insert blocks at point locations")
  
  ;; Step 1: Select points
  (prompt "\nSelect POINT entities: ")
  (setq ss (ssget '((0 . "POINT"))))
  
  (cond
    ;; No points selected
    ((not ss)
     (princ "\nNo points selected. Operation cancelled.")
    )
    
    ;; Points selected
    (t
     ;; Count selected points
     (setq insertCount (sslength ss))
     (princ (strcat "\nSelected " (itoa insertCount) " point(s)."))
     
     ;; Step 2: Get block name
     (initget 1) ; Force user to enter a value
     (setq blockName (getstring t "\nEnter block name to insert: "))
     
     ;; Step 3: Check if block exists
     (setq blockObj (tblobjname "BLOCK" blockName))
     
     (cond
      ;; Block doesn't exist
      ((not blockObj)
       (princ (strcat "\nError: Block '" blockName "' does not exist in this drawing."))
      )
      
      ;; Block exists - proceed with insertion
      (t
       (princ (strcat "\nInserting " (itoa insertCount) " blocks..."))
       
       ;; Disable command echoing for speed
       (setvar "CMDECHO" 0)
       
       ;; Process each selected point
       (setq ptList '())
       (setq i 0)
       (repeat (sslength ss)
         (setq pt (cdr (assoc 10 (entget (ssname ss i)))))
         (setq ptList (cons pt ptList))
         (setq i (1+ i))
       )
       
       ;; Insert blocks at each point location
       (foreach pt ptList
         (command "_.INSERT" blockName pt 1.0 1.0 0.0)
       )
       
       ;; Restore command echoing
       (setvar "CMDECHO" 1)
       
       ;; Display completion message
       (princ (strcat "\n✓ Successfully inserted " 
                      (itoa insertCount) 
                      " block(s) named '" 
                      blockName 
                      "'."))
      )
     )
    )
  )
  
  ;; Clean exit
  (princ)
)

;;; Load command
(princ "\nPointToBlock loaded successfully.")
(princ "\nType PTB to run the command.")
(princ)

;; ---- PTBL : সিলেক্ট করা POINT গুলোর জায়গায় নির্দিষ্ট ব্লক ইনসার্ট করে (দ্রুত, no dialog)।
;; (source: PTBL Block.lsp)
(defun c:PTBL (/ ss blkName i ent pt)

  (setq blkName (getstring T "\nEnter Block Name: "))

  ;; Check block exists
  (if (tblsearch "BLOCK" blkName)

    (progn

      ;; Select points
      (setq ss (ssget '((0 . "POINT"))))

      (if ss
        (progn
          (setq i 0)

          (repeat (sslength ss)

            (setq ent (ssname ss i))
            (setq pt (cdr (assoc 10 (entget ent))))

            ;; Insert block at point location
            (command "_.-INSERT"
                     blkName
                     pt
                     1
                     1
                     0
            )

            (setq i (1+ i))
          )

          (princ "\nBlock inserted at all points.")

        )
        (princ "\nNo points selected.")
      )

    )

    (princ "\nBlock not found.")

  )

  (princ)
)


;; ================================================================
;; CATEGORY: টেক্সট ও অ্যানোটেশন টুলস (Text & Annotation Tools)
;; ================================================================

;; ---- T110 : সিলেক্ট করা টেক্সট/এম-টেক্সটকে "110" এ পরিবর্তন করে।
;; (source: 110 text.lsp)
(defun c:T110 (/ ent obj)
  (vl-load-com)

  (while (setq ent (car (entsel "\nSelect Text/Mtext: ")))
    (setq obj (vlax-ename->vla-object ent))

    (if (member (vla-get-ObjectName obj) '("AcDbText" "AcDbMText"))
      (progn
        (vla-put-TextString obj "110")
        (princ "\nText changed to 110.")
      )
      (princ "\nSelected object is not Text.")
    )
  )

  (princ)
)

;; ---- CH110 : সিলেকশন সেটের সকল টেক্সট থেকে "90" খুঁজে "110" এ পরিবর্তন করে।
;; (source: 110.lsp)
(defun c:CH110 (/ ss i ent obj txt)
  (vl-load-com)

  (if (setq ss (ssget '((0 . "TEXT,MTEXT"))))
    (progn
      (setq i 0)
      (while (< i (sslength ss))
        (setq ent (ssname ss i))
        (setq obj (vlax-ename->vla-object ent))
        (setq txt (vla-get-TextString obj))

        (setq txt (vl-string-subst "110" "90" txt))

        (vla-put-TextString obj txt)

        (setq i (1+ i))
      )
      (princ "\nText changed from 90 to 110.")
    )
  )

  (princ)
)

;; ---- UL : সিলেক্ট করা টেক্সট/এম-টেক্সটকে আন্ডারলাইন করে।
;; (source: UL.lsp)
(defun c:UL ( / e txt objtype newtxt )

  ;; Select text
  (setq e (car (entsel "\nSelect text to underline: ")))

  (if e
    (progn
      (setq txt (entget e))
      (setq objtype (cdr (assoc 0 txt)))

      ;; Get current text
      (setq oldtxt (cdr (assoc 1 txt)))

      ;; TEXT object
      (if (= objtype "TEXT")
        (setq newtxt (strcat "%%U" oldtxt "%%U"))
      )

      ;; MTEXT object
      (if (= objtype "MTEXT")
        (setq newtxt (strcat "\\L" oldtxt "\\l"))
      )

      ;; Replace text
      (setq txt (subst (cons 1 newtxt) (assoc 1 txt) txt))
      (entmod txt)
      (entupd e)

      (princ "\nText underlined.")
    )
  )

  (princ)
)

;; ---- JTO : দুইটি টেক্সটের মান নিয়ে মাঝে "to" লিখে আন্ডারলাইনসহ নতুন টেক্সট তৈরি করে।
;; (source: JTO.lsp)
(defun c:JTO ( / t1 t2 t3 e1 e2 e3 v1 v2 newtxt )

  ;; Select texts
  (setq e1 (car (entsel "\nSelect 1st text: ")))
  (setq e2 (car (entsel "\nSelect 2nd text: ")))
  (setq e3 (car (entsel "\nSelect target text: ")))

  ;; Get text values
  (setq v1 (cdr (assoc 1 (entget e1))))
  (setq v2 (cdr (assoc 1 (entget e2))))

  ;; Create underlined text
  ;; %%U works for TEXT and MTEXT
  (setq newtxt (strcat "%%U" v1 " to " v2 "%%U"))

  ;; Replace target text
  (setq t3 (entget e3))
  (setq t3 (subst (cons 1 newtxt) (assoc 1 t3) t3))
  (entmod t3)
  (entupd e3)

  (princ (strcat "\nUpdated text: " newtxt))
  (princ)
)

;; ---- LPEP : সিলেক্ট করা সব সার্কেলের ভেতরে নির্দিষ্ট টেক্সট বসিয়ে দেয়।
;; (source: LP EP.lsp)
(defun c:LPEP ( / ss i ent cen txt ht)

  ;; ইউজার থেকে টেক্সট ইনপুট নেওয়া
  (setq txt (getstring T "\nEnter text to place inside circles: "))

  ;; text height (চাইলে change করো বা input করাতে পারো)
  (setq ht 0.5)

  ;; circle select করা
  (setq ss (ssget '((0 . "CIRCLE"))))

  (if ss
    (progn
      (setq i 0)
      (repeat (sslength ss)

        (setq ent (ssname ss i))
        (setq cen (cdr (assoc 10 (entget ent))))

        ;; text create (center aligned)
        (entmake
          (list
            (cons 0 "TEXT")
            (cons 10 cen)
            (cons 40 ht)
            (cons 1 txt)
            (cons 7 "STANDARD")
            (cons 72 1)
            (cons 73 2)
            (cons 11 cen)
          )
        )

        (setq i (1+ i))
      )
    )
  )

  (princ "\nText placed inside selected circles.")
  (princ)
)


;; ================================================================
;; CATEGORY: লেয়ার টুলস (Layer Tools)
;; ================================================================

;; ---- SDLW : সিলেকশনের লেয়ার তালিকা দেখায় এবং পছন্দমতো লেয়ার সিলেক্ট করতে দেয়।
;; (source: SDLW.lsp)
(defun c:SDLW (/ ss i ent lay layers laylist n choice target ss2)

  (vl-load-com)

  (if (setq ss (ssget))
    (progn

      ;; Build unique layer list
      (setq layers '())
      (setq i 0)

      (while (< i (sslength ss))
        (setq ent (ssname ss i))
        (setq lay (cdr (assoc 8 (entget ent))))

        (if (not (member (strcase lay) (mapcar 'strcase layers)))
          (setq layers (append layers (list lay)))
        )

        (setq i (1+ i))
      )

      ;; Display layers
      (princ "\nAvailable Layers:")
      (setq n 1)

      (foreach lay layers
        (princ
          (strcat
            "\n"
            (itoa n)
            " - "
            lay
          )
        )
        (setq n (1+ n))
      )

      ;; Ask user
      (setq choice
        (getint
          (strcat
            "\nSelect Layer Number (1-"
            (itoa (length layers))
            "): "
          )
        )
      )

      (if (and choice
               (>= choice 1)
               (<= choice (length layers)))

        (progn

          (setq target (nth (1- choice) layers))
          (setq ss2 (ssadd))

          (setq i 0)
          (while (< i (sslength ss))

            (setq ent (ssname ss i))

            (if (= (strcase target)
                   (strcase (cdr (assoc 8 (entget ent)))))
              (ssadd ent ss2)
            )

            (setq i (1+ i))
          )

          (sssetfirst nil ss2)

          (princ
            (strcat
              "\nLayer Selected: "
              target
            )
          )
        )
      )
    )
  )

  (princ)
)


;; ================================================================
;; CATEGORY: লেআউট ও শীট ম্যানেজমেন্ট টুলস (Layout & Sheet Management Tools)
;; ================================================================

;; ---- ACAD : Model বাদে সব লেআউটকে "DWG To PDF.pc3" + "acad.ctb" প্লট স্টাইলে সেট করে।
;; (source: ACAD.lsp)
(defun c:acad ( / doc lays )
  (vl-load-com)
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setq lays (vla-get-Layouts doc))
  (vlax-for lay lays
    (if (/= (vla-get-Name lay) "Model")
      (progn
        (vla-put-ConfigName lay "DWG To PDF.pc3")
        (vla-put-StyleSheet lay "acad.ctb")
      )
    )
  )
  (princ)
)

;; ---- CTBACA : সব লেআউটকে (Model সহ) "DWG To PDF.pc3" + "acad.ctb" প্লট স্টাইলে সেট করে।
;; (source: New Text Document.lsp)
(defun c:CTBACA (/ doc lays lay)
  (vl-load-com)

  (setq doc  (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setq lays (vla-get-Layouts doc))

  (vlax-for lay lays
    (vla-put-ConfigName lay "DWG To PDF.pc3")
    (vla-put-StyleSheet lay "acad.ctb")
  )

  (princ "\nAll layouts changed to acad.ctb")
  (princ)
)

;; ---- CLRLAYTXT : সব লেআউট থেকে টেক্সট/এম-টেক্সট মুছে ফেলে (ব্লকের ভিতরের টেক্সট বাদে)।
;; (source: CLEARYTXT.lsp)
(defun c:CLRLAYTXT (/ layouts lay ss i ent obj)
  (vl-load-com)

  ;; সব Layout Loop
  (foreach lay (layoutlist)

    ;; Current layout active করা
    (setvar "CTAB" lay)

    ;; শুধু TEXT ও MTEXT select করবে
    (if (setq ss (ssget "X" '((0 . "TEXT,MTEXT"))))
      (progn
        (setq i 0)

        (while (< i (sslength ss))
          (setq ent (ssname ss i))
          (setq obj (vlax-ename->vla-object ent))

          ;; Block এর ভিতরের text না হলে delete করবে
          (if (= (vla-get-OwnerID obj)
                 (vla-get-ObjectID
                   (vla-get-Block
                     (vla-get-ActiveLayout
                       (vla-get-ActiveDocument
                         (vlax-get-acad-object)
                       )
                     )
                   )
                 )
              )
            (vla-delete obj)
          )

          (setq i (1+ i))
        )
      )
    )
  )

  (princ "\nAll layout texts deleted except block texts & viewports.")
  (princ)
)

;; ---- FFFVPFIND : নির্দিষ্ট টেক্সট খুঁজে বের করে জুম করে ও সিলেক্ট করে দেয়।
;; (source: FFFVPFIND.lsp)
(defun c:FFFVPFIND (/ txt ss i ent ed found sset)

  (setq txt (getstring T "\nEnter text to find: "))

  (setq ss
    (ssget "_X"
      '((0 . "TEXT,MTEXT"))
    )
  )

  (setq found nil)

  (if ss
    (progn
      (setq i 0)

      (while (and (< i (sslength ss)) (not found))
        (setq ent (ssname ss i))
        (setq ed  (entget ent))

        (if (wcmatch
              (strcase (cdr (assoc 1 ed)))
              (strcat "*" (strcase txt) "*")
            )
          (setq found ent)
        )

        (setq i (1+ i))
      )

      (if found
        (progn
          ;; Selection Set তৈরি
          (setq sset (ssadd))
          (ssadd found sset)

          ;; Object এ Zoom
          (command "_.ZOOM" "_OBJECT" found "")

          ;; Object Select
          (sssetfirst nil sset)

          (redraw)

          (princ
            (strcat
              "\nFound and selected text: "
              (cdr (assoc 1 (entget found)))
            )
          )
        )
        (princ "\nText not found.")
      )
    )
    (princ "\nNo text objects found in drawing.")
  )

  (princ)
)

;; ---- LAYREN : লেআউটগুলোকে নির্দিষ্ট প্রিফিক্স ও সিরিয়াল নম্বর দিয়ে রিনেম করে।
;; (source: LAYREN.lsp)
(defun c:LAYREN (/ prefix doc lays laylist i lay obj)

  (vl-load-com)

  (setq prefix (getstring "\nEnter Prefix (e.g. SH-): "))
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setq lays (vla-get-Layouts doc))

  ;; Get layouts with tab order
  (setq laylist '())

  (vlax-for obj lays
    (if (/= (strcase (vla-get-Name obj)) "MODEL")
      (setq laylist
        (append laylist
          (list
            (cons
              (vla-get-TabOrder obj)
              (vla-get-Name obj)
            )
          )
        )
      )
    )
  )

  ;; Sort layouts by tab order
  (setq laylist
    (vl-sort laylist
      '(lambda (a b)
         (< (car a) (car b))
       )
    )
  )

  ;; Rename layouts
  (setq i 1)

  (foreach lay laylist
    (command "_.LAYOUT" "_RENAME"
             (cdr lay)
             (strcat prefix "(" (itoa i) ")")
    )
    (setq i (1+ i))
  )

  (princ "\nLayouts Renamed Successfully.")
  (princ)
)

;; ---- LAYSORTNUM : লেআউটের নামের নম্বর অনুযায়ী ট্যাব অর্ডার সাজিয়ে দেয়।
;; (source: LAYSORTNUM.lsp)
(defun extract-num (s)
  (atoi (vl-list->string
    (vl-remove-if-not
      '(lambda (c) (and (>= c 48) (<= c 57)))
      (vl-string->list s)
    )
  ))
)

(defun sort-layouts (lst)
  (vl-sort lst
    '(lambda (a b)
       (< (extract-num a) (extract-num b))
     )
  )
)

(defun c:LAYSORTNUM (/ acad doc lays sorted idx)

  (vl-load-com)

  (setq acad (vlax-get-acad-object))
  (setq doc (vla-get-ActiveDocument acad))

  ;; Get layouts
  (setq lays (layoutlist))

  ;; Remove Model
  (setq lays (vl-remove "Model" lays))

  ;; Numeric sort
  (setq sorted (sort-layouts lays))

  ;; Apply tab order
  (setq idx 1)

  (foreach lay sorted
    (vla-put-TabOrder
      (vla-Item (vla-get-Layouts doc) lay)
      idx
    )
    (setq idx (1+ idx))
  )

  (princ "\nLayouts reordered numerically.")
  (princ)
)

;; ---- NEXTLAY : পরবর্তী লেআউটে সুইচ করে (শেষে থাকলে প্রথমে ফিরে আসে)।
;; (source: NEXTLAY.lsp)
(defun c:NEXTLAY (/ lays cur idx nextlay)
  (setq lays (layoutlist))
  (setq cur (getvar "CTAB"))

  ;; Current layout index বের করা
  (setq idx (vl-position cur lays))

  ;; Next layout নির্ধারণ
  (if (< idx (1- (length lays)))
    (setq nextlay (nth (1+ idx) lays))
    (setq nextlay (car lays)) ; শেষ হলে আবার প্রথমে যাবে
  )

  ;; Layout change
  (setvar "CTAB" nextlay)

  (princ (strcat "\nSwitched to layout: " nextlay))
  (princ)
)

;; ---- NSYNC : নর্থ সাইন ব্লককে ভিউপোর্টের টুইস্ট অ্যাঙ্গেল অনুযায়ী ঘোরায়।
;; (source: NSYNC.lsp)
(defun c:NSYNC (/ blk vp vpobj ang)

  (vl-load-com)

  (setq blk (car (entsel "\nSelect North Sign Block: ")))
  (setq vp  (car (entsel "\nSelect Viewport: ")))

  (if (and blk vp)
    (progn

      (setq vpobj (vlax-ename->vla-object vp))

      ;; Get viewport twist angle
      (setq ang (vla-get-twistangle vpobj))

      ;; Set block rotation directly
      (vla-put-rotation
        (vlax-ename->vla-object blk)
        (- ang)
      )

      (princ "\nNorth sign synced.")
    )
  )

  (princ)
)

;; ---- SSSCOPY : কারেন্ট লেআউট (যেমন (01)) কপি করে পরের সিরিয়াল নম্বরসহ নতুন লেআউট তৈরি করে।
;; (source: SHCOPY.lsp)
(defun c:SSSCOPY (/ curLay num newLay)

  (vl-load-com)

  ;; Current Layout Name
  (setq curLay (getvar "CTAB"))

  ;; Extract number from (01)
  (if (and (vl-string-search "(" curLay)
           (vl-string-search ")" curLay))

    (progn

      (setq num
        (atoi
          (substr curLay
                  (+ (vl-string-search "(" curLay) 2)
                  (- (vl-string-search ")" curLay)
                     (vl-string-search "(" curLay)
                     1)
          )
        )
      )

      ;; Next Number
      (setq num (1+ num))

      ;; New Layout Name
      (if (< num 10)
        (setq newLay (strcat "(0" (itoa num) ")"))
        (setq newLay (strcat "(" (itoa num) ")"))
      )

      ;; Copy Layout
      (command "_.LAYOUT" "_COPY" curLay newLay)

      ;; Move To End
      (command "_.LAYOUT" "_MOVE" newLay "")

      ;; Switch To New Layout
      (setvar "CTAB" newLay)

      (princ (strcat "\nNew Layout Created: " newLay))
    )

    (princ "\nLayout name must be like (01)")
  )

  (princ)
)

;; ---- SHNO : কারেন্ট লেআউট নাম অনুযায়ী ডাইনামিক শিট নম্বর টেক্সট (ফিল্ড) তৈরি করে।
;; (source: SHNO.lsp)
(defun c:SHNO (/ pt fld)

  (setq pt (getpoint "\nPick point for Sheet Number: "))

  ;; Layout name field
  (setq fld "%<\\AcVar ctab>%")

  ;; Create TEXT
  (entmakex
    (list
      '(0 . "TEXT")
      '(100 . "AcDbEntity")
      '(100 . "AcDbText")
      (cons 10 pt)
      (cons 40 2.5) ;; Text Height
      (cons 1 fld)
      (cons 7 (getvar "TEXTSTYLE"))
    )
  )

  (princ "\nDynamic Sheet Number Created.")
  (princ)
)

;; ---- SNO-DRWNO : শিট সিরিয়াল + ড্রয়িং নম্বর একসাথে বসিয়ে দেয়।
;; (source: SNO-DRWNO.lsp)
(defun c:SNO-DRWNO (/ serial dwgno finalText ent obj)

  (vl-load-com)

  ;; Sheet Serial
  (setq serial
    (getstring T "\nEnter Sheet Serial (e.g. 01): ")
  )

  ;; Drawing Number
  (setq dwgno
    (getstring T "\nEnter Drawing No. (e.g. KWASA-P7-C-001): ")
  )

  ;; Combine Sheet Serial + Drawing No.
  (setq finalText
    (strcat serial " - " dwgno)
  )

  ;; Select Sheet Drawing No. Text
  (setq ent
    (car
      (entsel
        "\nSelect Sheet Drawing No. Text: "
      )
    )
  )

  (if ent
    (progn

      (setq obj
        (vlax-ename->vla-object ent)
      )

      ;; TEXT
      (if (= (vla-get-ObjectName obj) "AcDbText")
        (progn
          (vla-put-TextString obj finalText)
          (princ
            (strcat
              "\nUpdated: "
              finalText
            )
          )
        )
      )

      ;; MTEXT
      (if (= (vla-get-ObjectName obj) "AcDbMText")
        (progn
          (vla-put-TextString obj finalText)
          (princ
            (strcat
              "\nUpdated: "
              finalText
            )
          )
        )
      )

    )
    (princ "\nNo text selected.")
  )

  (princ)
)

;; ---- VPLOCKALL : সব লেআউটের ভিউপোর্ট একসাথে লক/আনলক করে।
;; (source: VP lock.lsp)
(defun c:vplockall (/ X lck prmpt)
  (vl-load-com)
  (initget 0 "Lock Unlock")
  (setq X (getkword "\n (L)ock or (U)nlock all viewports? "))
  (setq lck (if (= X "Lock") :vlax-true :vlax-false))
  (vlax-for lay (vla-get-layouts (vla-get-activedocument (vlax-get-acad-object)))
    (if (eq :vlax-false (vla-get-modeltype lay))
      (vlax-for ent (vla-get-block lay)
        (if (= (vla-get-objectname ent) "AcDbViewport")
          (vla-put-displaylocked ent lck)
        )
      )
    )
  )
  (princ "\n সব Viewport লক/আনলক সম্পন্ন!")
)


;; ================================================================
;; AH / AUTOCADHELPER  --  category-wise command menu (help)
;; ================================================================

(defun c:AUTOCADHELPER ( / )
  (princ "\n============================================================")
  (princ "\n   AUTOCAD HELPER by EVLab - Command List")
  (princ "\n============================================================")
  (princ "\n\n>> সার্ভে ও পয়েন্ট টুলস (Survey & Point Tools)")
  (princ "\n   FPOINT     - নির্দিষ্ট পয়েন্টে ডোনাট (survey marker) তৈরি করে, ডায়ামিটার সেট করা যায়।")
  (princ "\n   FPSTYLE    - পয়েন্ট স্টাইলকে ফিল্ড সার্কেল (গোল পয়েন্ট) এ পরিবর্তন করে।")
  (princ "\n   PFILL      - সিলেক্ট করা POINT গুলোকে রঙ ও ফিল্ড-সার্কেল স্টাইলে (survey marker) পরিণত করে।")
  (princ "\n   PCT        - সিলেক্ট করা POINT গুলোর জায়গায় (RL/Chainage ইত্যাদি) টেক্সট বসায়।")
  (princ "\n   PTB        - সিলেক্ট করা POINT গুলোর জায়গায় নির্দিষ্ট ব্লক ইনসার্ট করে (ডায়ালগসহ, রিপোর্টসহ)।")
  (princ "\n   PTBL       - সিলেক্ট করা POINT গুলোর জায়গায় নির্দিষ্ট ব্লক ইনসার্ট করে (দ্রুত, no dialog)।")
  (princ "\n\n>> টেক্সট ও অ্যানোটেশন টুলস (Text & Annotation Tools)")
  (princ "\n   T110       - সিলেক্ট করা টেক্সট/এম-টেক্সটকে "110" এ পরিবর্তন করে।")
  (princ "\n   CH110      - সিলেকশন সেটের সকল টেক্সট থেকে "90" খুঁজে "110" এ পরিবর্তন করে।")
  (princ "\n   UL         - সিলেক্ট করা টেক্সট/এম-টেক্সটকে আন্ডারলাইন করে।")
  (princ "\n   JTO        - দুইটি টেক্সটের মান নিয়ে মাঝে "to" লিখে আন্ডারলাইনসহ নতুন টেক্সট তৈরি করে।")
  (princ "\n   LPEP       - সিলেক্ট করা সব সার্কেলের ভেতরে নির্দিষ্ট টেক্সট বসিয়ে দেয়।")
  (princ "\n\n>> লেয়ার টুলস (Layer Tools)")
  (princ "\n   SDLW       - সিলেকশনের লেয়ার তালিকা দেখায় এবং পছন্দমতো লেয়ার সিলেক্ট করতে দেয়।")
  (princ "\n\n>> লেআউট ও শীট ম্যানেজমেন্ট টুলস (Layout & Sheet Management Tools)")
  (princ "\n   ACAD       - Model বাদে সব লেআউটকে "DWG To PDF.pc3" + "acad.ctb" প্লট স্টাইলে সেট করে।")
  (princ "\n   CTBACA     - সব লেআউটকে (Model সহ) "DWG To PDF.pc3" + "acad.ctb" প্লট স্টাইলে সেট করে।")
  (princ "\n   CLRLAYTXT  - সব লেআউট থেকে টেক্সট/এম-টেক্সট মুছে ফেলে (ব্লকের ভিতরের টেক্সট বাদে)।")
  (princ "\n   FFFVPFIND  - নির্দিষ্ট টেক্সট খুঁজে বের করে জুম করে ও সিলেক্ট করে দেয়।")
  (princ "\n   LAYREN     - লেআউটগুলোকে নির্দিষ্ট প্রিফিক্স ও সিরিয়াল নম্বর দিয়ে রিনেম করে।")
  (princ "\n   LAYSORTNUM - লেআউটের নামের নম্বর অনুযায়ী ট্যাব অর্ডার সাজিয়ে দেয়।")
  (princ "\n   NEXTLAY    - পরবর্তী লেআউটে সুইচ করে (শেষে থাকলে প্রথমে ফিরে আসে)।")
  (princ "\n   NSYNC      - নর্থ সাইন ব্লককে ভিউপোর্টের টুইস্ট অ্যাঙ্গেল অনুযায়ী ঘোরায়।")
  (princ "\n   SSSCOPY    - কারেন্ট লেআউট (যেমন (01)) কপি করে পরের সিরিয়াল নম্বরসহ নতুন লেআউট তৈরি করে।")
  (princ "\n   SHNO       - কারেন্ট লেআউট নাম অনুযায়ী ডাইনামিক শিট নম্বর টেক্সট (ফিল্ড) তৈরি করে।")
  (princ "\n   SNO-DRWNO  - শিট সিরিয়াল + ড্রয়িং নম্বর একসাথে বসিয়ে দেয়।")
  (princ "\n   VPLOCKALL  - সব লেআউটের ভিউপোর্ট একসাথে লক/আনলক করে।")
  (princ "\n\n============================================================")
  (princ "\nType any command above to run it. Type AH anytime to see this menu again.")
  (princ)
)

(defun c:AH () (c:AUTOCADHELPER))

;; ---- Startup banner (shown once, when this file is loaded) ----
(princ "\n\nAutoCAD Helper (EVLab) loaded successfully.")
(princ "\nType  AH  to see the full category-wise command list.\n")
(princ)
