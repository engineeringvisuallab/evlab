;=========================================================================
;; SURVEYPRO SUITE - TOOL 17: QCPOINTS.LSP
;; Purpose: Detect Duplicate Coordinates, Zero Elevations & Bad Survey Points
;; Author: SurveyPro Cad Systems (c) 2026
;;=========================================================================

(defun c:QCPOINTS ( / *error* ss cnt i j ent1 ent2 p1 p2 tol dupCount zeroCount z)
  (vl-load-com)

  (defun *error* (msg)
    (if (and msg (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*")))
      (princ (strcat "\n[QCPOINTS Error]: " msg)))
    (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
    (setvar "CMDECHO" 1)
    (princ)
  )

  (setvar "CMDECHO" 0)
  (vla-StartUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))

  (princ "\n--- [SURVEYPRO] Survey Point Quality Control Scanner ---")
  (setq ss (ssget "X" '((0 . "POINT"))))

  (if ss
    (progn
      (setq tol (getdist "\nSpecify duplicate proximity tolerance in meters <0.010>: "))
      (if (null tol) (setq tol 0.010))

      (if (null (tblsearch "LAYER" "SURV-QC-FLAG"))
        (command "_.-LAYER" "_M" "SURV-QC-FLAG" "_C" "1" "" ""))

      (setq cnt (sslength ss)
            dupCount 0
            zeroCount 0
            i 0)
      
      (princ (strcat "\nScanning " (itoa cnt) " survey points..."))

      (while (< i cnt)
        (setq ent1 (ssname ss i))
        (setq p1 (cdr (assoc 10 (entget ent1))))
        (setq z (caddr p1))

        ;; Check Zero Elevation
        (if (< (abs z) 0.0001)
          (progn
            (setq zeroCount (1+ zeroCount))
            (entmake (list '(0 . "CIRCLE")
                           '(100 . "AcDbEntity")
                           '(8 . "SURV-QC-FLAG")
                           '(100 . "AcDbCircle")
                           (cons 10 p1)
                           (cons 40 1.5)))))

        ;; Check duplicates against remaining points
        (setq j (1+ i))
        (while (< j cnt)
          (setq ent2 (ssname ss j))
          (setq p2 (cdr (assoc 10 (entget ent2))))
          (if (< (distance (list (car p1) (cadr p1)) (list (car p2) (cadr p2))) tol)
            (progn
              (setq dupCount (1+ dupCount))
              (entmake (list '(0 . "CIRCLE")
                             '(100 . "AcDbEntity")
                             '(8 . "SURV-QC-FLAG")
                             '(100 . "AcDbCircle")
                             (cons 10 p1)
                             (cons 40 2.0)))))
          (setq j (1+ j))
        )
        (setq i (1+ i))
      )

      (princ "\n==========================================")
      (princ "\n SURVEYPRO QC AUDIT REPORT")
      (princ (strcat "\n Total Points Scanned : " (itoa cnt)))
      (princ (strcat "\n Co-located Duplicates: " (itoa dupCount)))
      (princ (strcat "\n Zero Elevation Points: " (itoa zeroCount)))
      (princ "\n==========================================")
      (if (or (> dupCount 0) (> zeroCount 0))
        (princ "\nFlags have been placed on layer 'SURV-QC-FLAG'.")
        (princ "\n[Clean]: No survey point anomalies detected."))
    )
    (princ "\nNo points in drawing.")
  )

  (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setvar "CMDECHO" 1)
  (princ)
)
(princ "\n[SURVEYPRO] Type QCPOINTS to run Point QC Scanner.")
(princ)