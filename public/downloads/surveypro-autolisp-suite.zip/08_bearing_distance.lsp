;=========================================================================
;; SURVEYPRO SUITE - TOOL 08: SURVBD.LSP
;; Purpose: Instant Bearing & Distance Calculator with DMS & Slope
;; Author: SurveyPro Cad Systems (c) 2026
;;=========================================================================

(defun c:SURVBD ( / *error* p1 p2 dx dy dz hd sd az rad d m s dmsStr placeLbl midPt ang)
  (vl-load-com)

  (defun *error* (msg)
    (if (and msg (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*")))
      (princ (strcat "\n[SURVBD Error]: " msg)))
    (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
    (setvar "CMDECHO" 1)
    (princ)
  )

  (setvar "CMDECHO" 0)
  (vla-StartUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))

  ;; DecDeg to DMS conversion
  (defun deg-to-dms (deg / d m s)
    (setq d (fix deg))
    (setq m (fix (* (- deg d) 60.0)))
    (setq s (* (- (* (- deg d) 60.0) m) 60.0))
    (strcat (itoa d) "%%d" (if (< m 10) (strcat "0" (itoa m)) (itoa m)) "'" (rtos s 2 1) "\"")
  )

  (princ "\n--- [SURVEYPRO] Bearing & Distance Calculator ---")
  (setq p1 (getpoint "\nSelect First Survey Point: "))
  (if p1
    (progn
      (setq p2 (getpoint p1 "\nSelect Second Survey Point: "))
      (if p2
        (progn
          (setq dx (- (car p2) (car p1))
                dy (- (cadr p2) (cadr p1))
                dz (- (caddr p2) (caddr p1)))
          
          (setq hd (sqrt (+ (* dx dx) (* dy dy))))
          (setq sd (sqrt (+ (* dx dx) (* dy dy) (* dz dz))))
          
          ;; Mathematical Azimuth in degrees (0 = North, clockwise)
          (setq rad (atan dx dy)) ; Surveyor's atan(E/N)
          (if (< rad 0) (setq rad (+ rad (* 2.0 pi))))
          (setq az (* (/ rad pi) 180.0))
          (setq dmsStr (deg-to-dms az))

          (princ "\n==========================================")
          (princ (strcat "\n Horizontal Distance : " (rtos hd 2 3) " m"))
          (princ (strcat "\n Slope Distance      : " (rtos sd 2 3) " m"))
          (princ (strcat "\n Bearing / Azimuth   : " dmsStr " (" (rtos az 2 4) " deg)"))
          (princ (strcat "\n Delta Easting (dE)  : " (rtos dx 2 3) " m"))
          (princ (strcat "\n Delta Northing (dN) : " (rtos dy 2 3) " m"))
          (princ (strcat "\n Delta Elevation (dZ): " (rtos dz 2 3) " m"))
          (princ "\n==========================================")

          (initget "Yes No")
          (setq placeLbl (getkword "\nPlace bearing/distance label on drawing? [Yes/No] <Yes>: "))
          (if (or (null placeLbl) (= placeLbl "Yes"))
            (progn
              (if (null (tblsearch "LAYER" "SURV-DIM"))
                (command "_.-LAYER" "_M" "SURV-DIM" "_C" "140" "" ""))
              (setq midPt (list (/ (+ (car p1) (car p2)) 2.0)
                                (/ (+ (cadr p1) (cadr p2)) 2.0)
                                (/ (+ (caddr p1) (caddr p2)) 2.0)))
              (setq ang (angle p1 p2))
              (if (or (> ang (/ pi 2.0)) (< ang (- (/ pi 2.0))))
                (setq ang (+ ang pi)))

              (entmake (list '(0 . "TEXT")
                             '(100 . "AcDbEntity")
                             '(8 . "SURV-DIM")
                             '(100 . "AcDbText")
                             (cons 10 midPt)
                             (cons 40 1.2)
                             (cons 1 (strcat dmsStr "  " (rtos hd 2 2) "m"))
                             (cons 50 ang)
                             '(72 . 1)
                             '(73 . 2)
                             (cons 11 midPt)))
              (princ "\nLabel placed.")
            )
          )
        )
      )
    )
  )

  (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setvar "CMDECHO" 1)
  (princ)
)
(princ "\n[SURVEYPRO] Type SURVBD to run Bearing & Distance Calculator.")
(princ)