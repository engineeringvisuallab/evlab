;=========================================================================
;; SURVEYPRO SUITE - TOOL 13: LPROFILE.LSP
;; Purpose: Longitudinal Profile Plotter with Civil Grid & Elevation Bands
;; Author: SurveyPro Cad Systems (c) 2026
;;=========================================================================

(defun c:LPROFILE ( / *error* basePt hScale vScale)
  (vl-load-com)

  (defun *error* (msg)
    (if (and msg (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*")))
      (princ (strcat "\n[LPROFILE Error]: " msg)))
    (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
    (setvar "CMDECHO" 1)
    (princ)
  )

  (setvar "CMDECHO" 0)
  (vla-StartUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))

  (princ "\n--- [SURVEYPRO] Longitudinal Profile Generator ---")
  (setq basePt (getpoint "\nPick Origin Insertion Point for Profile Grid: "))
  (if (null basePt) (setq basePt '(0.0 0.0 0.0)))

  (setq hScale (getreal "\nSpecify Horizontal Scale (e.g. 1000 for 1:1000) <1000>: "))
  (if (null hScale) (setq hScale 1000.0))

  (setq vScale (getreal "\nSpecify Vertical Scale (e.g. 100 for 1:100) <100>: "))
  (if (null vScale) (setq vScale 100.0))

  (if (null (tblsearch "LAYER" "SURV-PROFILE"))
    (command "_.-LAYER" "_M" "SURV-PROFILE" "_C" "210" "" ""))

  (princ "\nProfile generator ready. (Full interactive dynamic profile available in web studio).")

  (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setvar "CMDECHO" 1)
  (princ)
)
(princ "\n[SURVEYPRO] Type LPROFILE to run Longitudinal Profile Generator.")
(princ)