;=========================================================================
;; SURVEYPRO SUITE - TOOL 03: CSV2SURV.LSP
;; Purpose: Professional CSV/TXT Survey Data Importer for AutoCAD
;; Author: SurveyPro Cad Systems (c) 2026
;;=========================================================================

(defun c:CSV2SURV ( / *error* fn file line tokens pno e n z desc count ht off)
  (vl-load-com)
  
  (defun *error* (msg)
    (if file (close file))
    (if (and msg (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*")))
      (princ (strcat "\n[CSV2SURV Error]: " msg))
    )
    (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
    (setvar "CMDECHO" 1)
    (princ)
  )

  (setvar "CMDECHO" 0)
  (vla-StartUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))

  ;; Fast CSV split helper
  (defun parse-csv-line (str / res ch inQuotes cur len i)
    (setq len (strlen str) i 1 cur "" inQuotes nil res nil)
    (while (<= i len)
      (setq ch (substr str i 1))
      (cond
        ((= ch """) (setq inQuotes (not inQuotes)))
        ((and (or (= ch ",") (= ch "\t") (= ch ";")) (not inQuotes))
         (setq res (cons cur res) cur ""))
        (T (setq cur (strcat cur ch))))
      (setq i (1+ i)))
    (reverse (cons cur res)))

  (princ "\n--- [SURVEYPRO] CSV Survey Data Importer ---")
  (setq fn (getfiled "Select Survey Point File" "" "csv;txt;xyz;dat" 8))

  (if fn
    (progn
      (setq ht (getdist "\nSpecify annotation text height <1.20>: "))
      (if (null ht) (setq ht 1.20))
      (setq off (* ht 0.75))

      ;; Initialize Layers
      (foreach lay '("SURV-POINT" "SURV-PNO" "SURV-ELEV" "SURV-DESC")
        (if (null (tblsearch "LAYER" lay))
          (command "_.-LAYER" "_M" lay "" "")))
      (command "_.-LAYER" "_C" "2" "SURV-POINT" "_C" "4" "SURV-PNO" "_C" "3" "SURV-ELEV" "_C" "6" "SURV-DESC" "" "")

      (setq file (open fn "r")
            count 0)
      
      (princ "\nImporting survey points...")

      (while (setq line (read-line file))
        (setq line (vl-string-trim " \t\r\n" line))
        (if (and (/= line "") (not (wcmatch (strcase line) "*POINT*,*EAST*,*NORTH*,*PNO*")))
          (progn
            (setq tokens (parse-csv-line line))
            (if (>= (length tokens) 3)
              (progn
                (if (= (length tokens) 3)
                  (setq pno (itoa (1+ count))
                        e (atof (nth 0 tokens))
                        n (atof (nth 1 tokens))
                        z (atof (nth 2 tokens))
                        desc "")
                  (setq pno (nth 0 tokens)
                        e (atof (nth 1 tokens))
                        n (atof (nth 2 tokens))
                        z (atof (nth 3 tokens))
                        desc (if (> (length tokens) 4) (nth 4 tokens) "")))
                
                ;; 1. Make Point
                (entmake (list '(0 . "POINT")
                               '(100 . "AcDbEntity")
                               '(8 . "SURV-POINT")
                               '(100 . "AcDbPoint")
                               (list 10 e n z)))
                
                ;; 2. Make Point Number Text
                (entmake (list '(0 . "TEXT")
                               '(100 . "AcDbEntity")
                               '(8 . "SURV-PNO")
                               '(100 . "AcDbText")
                               (list 10 (+ e off) (+ n off) z)
                               (cons 40 ht)
                               (cons 1 pno)))
                
                ;; 3. Make Elevation Text
                (entmake (list '(0 . "TEXT")
                               '(100 . "AcDbEntity")
                               '(8 . "SURV-ELEV")
                               '(100 . "AcDbText")
                               (list 10 (+ e off) (- (+ n off) (* ht 1.2)) z)
                               (cons 40 (* ht 0.85))
                               (cons 1 (rtos z 2 3))))
                
                ;; 4. Make Description Text (if available)
                (if (/= desc "")
                  (entmake (list '(0 . "TEXT")
                                 '(100 . "AcDbEntity")
                                 '(8 . "SURV-DESC")
                                 '(100 . "AcDbText")
                                 (list 10 (+ e off) (- (+ n off) (* ht 2.2)) z)
                                 (cons 40 (* ht 0.85))
                                 (cons 1 desc))))
                
                (setq count (1+ count))
              )
            )
          )
        )
      )
      (close file)
      (setq file nil)
      (princ (strcat "\n[Success]: Successfully imported " (itoa count) " survey points from " fn))
    )
  )

  (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setvar "CMDECHO" 1)
  (princ)
)
(princ "\n[SURVEYPRO] Type CSV2SURV to run CSV Importer.")
(princ)