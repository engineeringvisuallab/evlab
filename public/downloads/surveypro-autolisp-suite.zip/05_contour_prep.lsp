;=========================================================================
;; SURVEYPRO SUITE - TOOL 05: CONTOURPREP.LSP
;; Purpose: Contour Preparation & Elevation Mesh Analysis Assistant
;; Author: SurveyPro Cad Systems (c) 2026
;;=========================================================================

(defun c:CONTOURPREP ( / *error* ss cnt i ent pt z minZ maxZ minorInt majorInt pts)
  (vl-load-com)

  (defun *error* (msg)
    (if (and msg (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*")))
      (princ (strcat "\n[CONTOURPREP Error]: " msg)))
    (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
    (setvar "CMDECHO" 1)
    (princ)
  )

  (setvar "CMDECHO" 0)
  (vla-StartUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))

  (princ "\n--- [SURVEYPRO] Contour Preparation Assistant ---")
  (setq ss (ssget '((0 . "POINT"))))

  (if ss
    (progn
      (setq cnt (sslength ss) i 0
            minZ 1e9 maxZ -1e9 pts nil)
      
      (while (< i cnt)
        (setq ent (ssname ss i))
        (setq pt (cdr (assoc 10 (entget ent))))
        (setq z (caddr pt))
        (if (< z minZ) (setq minZ z))
        (if (> z maxZ) (setq maxZ z))
        (setq pts (cons pt pts))
        (setq i (1+ i))
      )

      (princ (strcat "\nTerrain Statistics: " (itoa cnt) " points scanned."))
      (princ (strcat "\nMinimum Elevation: " (rtos minZ 2 3) "m | Maximum Elevation: " (rtos maxZ 2 3) "m (Relief: " (rtos (- maxZ minZ) 2 3) "m)"))

      (setq minorInt (getreal "\nSpecify Minor Contour Interval <0.50>: "))
      (if (null minorInt) (setq minorInt 0.50))

      (setq majorInt (getreal "\nSpecify Major Index Contour Interval <2.50>: "))
      (if (null majorInt) (setq majorInt 2.50))

      ;; Create Contour Layers
      (if (null (tblsearch "LAYER" "SURV-CONTOUR-MAJ"))
        (command "_.-LAYER" "_M" "SURV-CONTOUR-MAJ" "_C" "30" "" "_LW" "0.35" "SURV-CONTOUR-MAJ" ""))
      (if (null (tblsearch "LAYER" "SURV-CONTOUR-MIN"))
        (command "_.-LAYER" "_M" "SURV-CONTOUR-MIN" "_C" "40" "" "_LW" "0.18" "SURV-CONTOUR-MIN" ""))

      (princ "\n[Success]: Survey contour layers and elevation range established.")
      (princ "\nUse CONTOURLBL to automatically label contour polylines.")
    )
    (princ "\nNo points selected.")
  )

  (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setvar "CMDECHO" 1)
  (princ)
)
(princ "\n[SURVEYPRO] Type CONTOURPREP to run Contour Assistant.")
(princ)