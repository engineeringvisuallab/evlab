;=========================================================================
;; SURVEYPRO SUITE - TOOL 15: COORDTBL.LSP
;; Purpose: Generate Professional Coordinate Table in AutoCAD
;; Author: SurveyPro Cad Systems (c) 2026
;;=========================================================================

(defun c:COORDTBL ( / *error* ss cnt i ent pt insPt doc space tbl row pno x y z)
  (vl-load-com)

  (defun *error* (msg)
    (if (and msg (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*")))
      (princ (strcat "\n[COORDTBL Error]: " msg)))
    (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
    (setvar "CMDECHO" 1)
    (princ)
  )

  (setvar "CMDECHO" 0)
  (vla-StartUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))

  (princ "\n--- [SURVEYPRO] Coordinate Table Generator ---")
  (setq ss (ssget '((0 . "POINT"))))

  (if ss
    (progn
      (setq insPt (getpoint "\nPick Table Top-Left Insertion Point: "))
      (if (null insPt) (setq insPt '(0.0 0.0 0.0)))

      (if (null (tblsearch "LAYER" "SURV-TABLE"))
        (command "_.-LAYER" "_M" "SURV-TABLE" "_C" "7" "" ""))

      (setq cnt (sslength ss))
      (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
      (setq space (vla-get-ModelSpace doc))

      ;; Create Table: (Rows = cnt + 2 headers, Cols = 4)
      (setq tbl (vla-AddTable space (vlax-3d-point insPt) (+ cnt 2) 4 3.0 25.0))
      (vla-put-Layer tbl "SURV-TABLE")

      ;; Title
      (vla-SetText tbl 0 0 "SURVEY POINT COORDINATE TABLE")

      ;; Headers
      (vla-SetText tbl 1 0 "POINT NO")
      (vla-SetText tbl 1 1 "EASTING (m)")
      (vla-SetText tbl 1 2 "NORTHING (m)")
      (vla-SetText tbl 1 3 "ELEVATION (m)")

      ;; Populate Rows
      (setq i 0 row 2)
      (while (< i cnt)
        (setq ent (ssname ss i))
        (setq pt (cdr (assoc 10 (entget ent))))
        (setq x (car pt) y (cadr pt) z (caddr pt))
        
        (vla-SetText tbl row 0 (strcat "P" (itoa (1+ i))))
        (vla-SetText tbl row 1 (rtos x 2 3))
        (vla-SetText tbl row 2 (rtos y 2 3))
        (vla-SetText tbl row 3 (rtos z 2 3))

        (setq row (1+ row))
        (setq i (1+ i))
      )

      (princ (strcat "\n[Success]: Coordinate Table created with " (itoa cnt) " points."))
    )
    (princ "\nNo points selected.")
  )

  (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setvar "CMDECHO" 1)
  (princ)
)
(princ "\n[SURVEYPRO] Type COORDTBL to run Coordinate Table Generator.")
(princ)