;=========================================================================
;; SURVEYPRO SUITE - TOOL 12: XSECTION.LSP
;; Purpose: Road Survey Cross Section Drawing Generator
;; Author: SurveyPro Cad Systems (c) 2026
;;=========================================================================

(defun c:XSECTION ( / *error* basePt hScale vScale)
  (vl-load-com)

  (defun *error* (msg)
    (if (and msg (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*")))
      (princ (strcat "\n[XSECTION Error]: " msg)))
    (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
    (setvar "CMDECHO" 1)
    (princ)
  )

  (setvar "CMDECHO" 0)
  (vla-StartUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))

  (princ "\n--- [SURVEYPRO] Cross Section Generator ---")
  (setq basePt (getpoint "\nPick Origin Insertion Point for Cross Section Sheets: "))
  (if (null basePt) (setq basePt '(0.0 0.0 0.0)))

  (setq hScale (getreal "\nSpecify Horizontal Scale (e.g. 100 for 1:100) <100>: "))
  (if (null hScale) (setq hScale 100.0))

  (setq vScale (getreal "\nSpecify Vertical Scale (e.g. 50 for 1:50) <50>: "))
  (if (null vScale) (setq vScale 50.0))

  (if (null (tblsearch "LAYER" "SURV-PROFILE"))
    (command "_.-LAYER" "_M" "SURV-PROFILE" "_C" "210" "" ""))

  (princ "\nCross Section generator initialized.")
  (princ "\nTip: You can use the interactive Corridor Studio in the Web App to slice and export DXF/SCR directly!")

  (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setvar "CMDECHO" 1)
  (princ)
)
(princ "\n[SURVEYPRO] Type XSECTION to run Cross Section Generator.")
(princ)