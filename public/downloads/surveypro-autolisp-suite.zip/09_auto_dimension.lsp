;=========================================================================
;; SURVEYPRO SUITE - TOOL 09: SURVDIM.LSP
;; Purpose: Auto Dimension Survey Lines and Boundary Polylines
;; Author: SurveyPro Cad Systems (c) 2026
;;=========================================================================

(defun c:SURVDIM ( / *error* ss cnt i ent obj p1 p2 off dimPt ang normal)
  (vl-load-com)

  (defun *error* (msg)
    (if (and msg (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*")))
      (princ (strcat "\n[SURVDIM Error]: " msg)))
    (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
    (setvar "CMDECHO" 1)
    (princ)
  )

  (setvar "CMDECHO" 0)
  (vla-StartUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))

  (princ "\n--- [SURVEYPRO] Auto Dimension Survey Linework ---")
  (setq ss (ssget '((0 . "LINE,LWPOLYLINE"))))

  (if ss
    (progn
      (setq off (getdist "\nSpecify dimension line offset distance <2.00>: "))
      (if (null off) (setq off 2.00))

      (if (null (tblsearch "LAYER" "SURV-DIM"))
        (command "_.-LAYER" "_M" "SURV-DIM" "_C" "140" "" ""))

      (setq cnt (sslength ss) i 0)
      (while (< i cnt)
        (setq ent (ssname ss i))
        (setq obj (vlax-ename->vla-object ent))

        (if (= (cdr (assoc 0 (entget ent))) "LINE")
          (progn
            (setq p1 (cdr (assoc 10 (entget ent))))
            (setq p2 (cdr (assoc 11 (entget ent))))
            (setq ang (angle p1 p2))
            (setq normal (+ ang (/ pi 2.0)))
            
            ;; Dimension line definition point
            (setq dimPt (list (+ (/ (+ (car p1) (car p2)) 2.0) (* off (cos normal)))
                              (+ (/ (+ (cadr p1) (cadr p2)) 2.0) (* off (sin normal)))
                              0.0))
            
            (command "_.DIMALIGNED" "_non" p1 "_non" p2 "_non" dimPt)
          )
        )
        (setq i (1+ i))
      )
      (princ (strcat "\n[Success]: Created dimensions on " (itoa cnt) " entities."))
    )
    (princ "\nNo lines or polylines selected.")
  )

  (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setvar "CMDECHO" 1)
  (princ)
)
(princ "\n[SURVEYPRO] Type SURVDIM to run Auto Dimension.")
(princ)