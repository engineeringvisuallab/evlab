;=========================================================================
;; SURVEYPRO SUITE - TOOL 02: XYZ2PT.LSP
;; Purpose: Convert Easting, Northing, Elevation coordinates into 3D Points
;; Author: SurveyPro Cad Systems (c) 2026
;;=========================================================================

(defun c:XYZ2PT ( / *error* rawStr lines line tokens e n z pno created)
  (vl-load-com)
  
  (defun *error* (msg)
    (if (and msg (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*")))
      (princ (strcat "\n[XYZ2PT Error]: " msg))
    )
    (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
    (setvar "CMDECHO" 1)
    (princ)
  )

  (setvar "CMDECHO" 0)
  (vla-StartUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))

  ;; String split helper
  (defun str-split (str delim / pos lst)
    (while (setq pos (vl-string-search delim str))
      (setq lst (cons (substr str 1 pos) lst)
            str (substr str (+ pos (1+ (strlen delim))))))
    (reverse (cons str lst))
  )

  (if (null (tblsearch "LAYER" "SURV-POINT"))
    (command "_.-LAYER" "_M" "SURV-POINT" "_C" "2" "" "")
  )

  (princ "\n--- [SURVEYPRO] Coordinate to 3D Point Converter ---")
  (princ "\nEnter or paste coordinates (Format: E,N,Z or P,E,N,Z):")
  
  (setq rawStr (getstring T "\nPaste line or type [E,N,Z]: "))
  (if (/= rawStr "")
    (progn
      (setq tokens (str-split rawStr ","))
      (if (< (length tokens) 3)
        (setq tokens (str-split rawStr " "))) ; fallback to space delimiter

      (cond
        ((= (length tokens) 3)
         (setq e (atof (nth 0 tokens))
               n (atof (nth 1 tokens))
               z (atof (nth 2 tokens)))
         (entmake (list '(0 . "POINT")
                        '(100 . "AcDbEntity")
                        '(8 . "SURV-POINT")
                        '(100 . "AcDbPoint")
                        (list 10 e n z)))
         (princ (strcat "\nCreated Point at E:" (rtos e 2 3) " N:" (rtos n 2 3) " Z:" (rtos z 2 3))))
        
        ((>= (length tokens) 4)
         (setq pno (nth 0 tokens)
               e (atof (nth 1 tokens))
               n (atof (nth 2 tokens))
               z (atof (nth 3 tokens)))
         (entmake (list '(0 . "POINT")
                        '(100 . "AcDbEntity")
                        '(8 . "SURV-POINT")
                        '(100 . "AcDbPoint")
                        (list 10 e n z)))
         (entmake (list '(0 . "TEXT")
                        '(100 . "AcDbEntity")
                        '(8 . "SURV-PNO")
                        '(100 . "AcDbText")
                        (list 10 (+ e 0.8) (+ n 0.8) z)
                        (cons 40 1.2)
                        (cons 1 pno)))
         (princ (strcat "\nCreated Point #" pno " at E:" (rtos e 2 3) " N:" (rtos n 2 3) " Z:" (rtos z 2 3))))
        
        (T (princ "\nInvalid coordinate format. Expected Easting, Northing, Elevation.")))
    )
  )

  (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setvar "CMDECHO" 1)
  (princ)
)
(princ "\n[SURVEYPRO] Type XYZ2PT to run Coordinate to Point creator.")
(princ)