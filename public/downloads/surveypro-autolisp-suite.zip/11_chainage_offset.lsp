;=========================================================================
;; SURVEYPRO SUITE - TOOL 11: CHOFFSET.LSP
;; Purpose: Calculate Chainage and Left/Right Offset of Survey Points
;; Author: SurveyPro Cad Systems (c) 2026
;;=========================================================================

(defun c:CHOFFSET ( / *error* clEnt clObj ss cnt i ent pt closePt param dist crossProd side offset station pno z)
  (vl-load-com)

  (defun *error* (msg)
    (if (and msg (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*")))
      (princ (strcat "\n[CHOFFSET Error]: " msg)))
    (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
    (setvar "CMDECHO" 1)
    (princ)
  )

  (setvar "CMDECHO" 0)
  (vla-StartUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))

  (princ "\n--- [SURVEYPRO] Chainage & Offset Calculator ---")
  (setq clEnt (car (entsel "\nSelect Centerline Alignment Polyline: ")))

  (if clEnt
    (progn
      (setq clObj (vlax-ename->vla-object clEnt))
      (princ "\nSelect survey points to calculate offsets:")
      (setq ss (ssget '((0 . "POINT"))))

      (if ss
        (progn
          (setq cnt (sslength ss) i 0)
          (princ "\n================================================================================")
          (princ "\n PNO     CHAINAGE       OFFSET(m)   SIDE    EASTING        NORTHING       ELEV(m)")
          (princ "\n================================================================================")

          (while (< i cnt)
            (setq ent (ssname ss i))
            (setq pt (cdr (assoc 10 (entget ent))))
            (setq closePt (vlax-curve-getClosestPointTo clObj pt))
            (setq param (vlax-curve-getParamAtPoint clObj closePt))
            (setq station (vlax-curve-getDistAtParam clObj param))
            (setq offset (distance (list (car pt) (cadr pt)) (list (car closePt) (cadr closePt))))
            
            ;; Determine Left or Right side via 2D Cross Product
            (setq deriv (vlax-curve-getFirstDeriv clObj param))
            (setq crossProd (- (* (car deriv) (- (cadr pt) (cadr closePt)))
                               (* (cadr deriv) (- (car pt) (car closePt)))))
            (if (> crossProd 0) (setq side "L") (setq side "R"))
            (if (< offset 0.001) (setq side "CL"))

            (princ (strcat "\n " (itoa (1+ i))
                           "\t" (rtos station 2 2)
                           "\t\t" (rtos offset 2 2)
                           "\t" side
                           "\t" (rtos (car pt) 2 3)
                           "\t" (rtos (cadr pt) 2 3)
                           "\t" (rtos (caddr pt) 2 3)))
            (setq i (1+ i))
          )
          (princ "\n================================================================================")
          (princ (strcat "\n[Success]: Calculated offsets for " (itoa cnt) " points."))
        )
        (princ "\nNo survey points selected.")
      )
    )
    (princ "\nNo centerline polyline selected.")
  )

  (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setvar "CMDECHO" 1)
  (princ)
)
(princ "\n[SURVEYPRO] Type CHOFFSET to run Chainage Offset Calculator.")
(princ)