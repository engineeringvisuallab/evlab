;=========================================================================
;; SURVEYPRO SUITE - TOOL 16: RENUMBERPT.LSP
;; Purpose: Batch Renumber Survey Points Sorted by Spatial Position
;; Author: SurveyPro Cad Systems (c) 2026
;;=========================================================================

(defun c:RENUMBERPT ( / *error* ss cnt i ent pt pts dir startNo step curNo)
  (vl-load-com)

  (defun *error* (msg)
    (if (and msg (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*")))
      (princ (strcat "\n[RENUMBERPT Error]: " msg)))
    (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
    (setvar "CMDECHO" 1)
    (princ)
  )

  (setvar "CMDECHO" 0)
  (vla-StartUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))

  (princ "\n--- [SURVEYPRO] Survey Point Renumbering Tool ---")
  (setq ss (ssget '((0 . "POINT"))))

  (if ss
    (progn
      (initget "LR RL TB BT")
      (setq dir (getkword "\nSort Direction [Left-to-Right(LR) / Right-to-Left(RL) / Top-to-Bottom(TB) / Bottom-to-Top(BT)] <LR>: "))
      (if (null dir) (setq dir "LR"))

      (setq startNo (getint "\nSpecify Starting Number <101>: "))
      (if (null startNo) (setq startNo 101))

      (setq step (getint "\nSpecify Increment Step <1>: "))
      (if (null step) (setq step 1))

      (setq cnt (sslength ss) i 0 pts nil)
      (while (< i cnt)
        (setq ent (ssname ss i))
        (setq pt (cdr (assoc 10 (entget ent))))
        (setq pts (cons (list ent pt) pts))
        (setq i (1+ i))
      )

      ;; Sort spatially
      (cond
        ((= dir "LR") (setq pts (vl-sort pts '(lambda (a b) (< (car (cadr a)) (car (cadr b)))))))
        ((= dir "RL") (setq pts (vl-sort pts '(lambda (a b) (> (car (cadr a)) (car (cadr b)))))))
        ((= dir "TB") (setq pts (vl-sort pts '(lambda (a b) (> (cadr (cadr a)) (cadr (cadr b)))))))
        ((= dir "BT") (setq pts (vl-sort pts '(lambda (a b) (< (cadr (cadr a)) (cadr (cadr b))))))))

      (setq curNo startNo)
      (foreach item pts
        (setq pt (cadr item))
        (entmake (list '(0 . "TEXT")
                       '(100 . "AcDbEntity")
                       '(8 . "SURV-PNO")
                       '(100 . "AcDbText")
                       (list 10 (+ (car pt) 0.8) (+ (cadr pt) 0.8) (caddr pt))
                       (cons 40 1.2)
                       (cons 1 (itoa curNo))))
        (setq curNo (+ curNo step))
      )
      (princ (strcat "\n[Success]: Renumbered " (itoa cnt) " points from #" (itoa startNo) " to #" (itoa (- curNo step))))
    )
    (princ "\nNo points selected.")
  )

  (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setvar "CMDECHO" 1)
  (princ)
)
(princ "\n[SURVEYPRO] Type RENUMBERPT to run Point Renumbering Tool.")
(princ)