;=========================================================================
;; SURVEYPRO SUITE - TOOL 18: SURVLAYERS.LSP
;; Purpose: Standard Civil & Land Survey Layer Auto Manager
;; Author: SurveyPro Cad Systems (c) 2026
;;=========================================================================

(defun c:SURVLAYERS ( / *error* layers item layName color ltype lweight)
  (vl-load-com)

  (defun *error* (msg)
    (if (and msg (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*")))
      (princ (strcat "\n[SURVLAYERS Error]: " msg)))
    (setvar "CMDECHO" 1)
    (princ)
  )

  (setvar "CMDECHO" 0)

  ;; Layer definitions: (Name Color Linetype Lineweight)
  (setq layers '(
    ("SURV-POINT"        "2"   "CONTINUOUS" "0.25")
    ("SURV-PNO"          "4"   "CONTINUOUS" "0.18")
    ("SURV-ELEV"         "3"   "CONTINUOUS" "0.18")
    ("SURV-DESC"         "6"   "CONTINUOUS" "0.18")
    ("SURV-BNDRY"        "7"   "CONTINUOUS" "0.50")
    ("SURV-ROAD-CL"      "5"   "CENTER"     "0.35")
    ("SURV-CHAINAGE"     "1"   "CONTINUOUS" "0.25")
    ("SURV-CONTOUR-MAJ"  "30"  "CONTINUOUS" "0.35")
    ("SURV-CONTOUR-MIN"  "40"  "CONTINUOUS" "0.18")
    ("SURV-DIM"          "140" "CONTINUOUS" "0.18")
    ("SURV-TABLE"        "7"   "CONTINUOUS" "0.25")
    ("SURV-PROFILE"      "210" "CONTINUOUS" "0.30")
    ("SURV-ANNO"         "7"   "CONTINUOUS" "0.25")
    ("SURV-QC-FLAG"      "1"   "HIDDEN"     "0.35")
  ))

  (princ "\n--- [SURVEYPRO] Standard Survey Layer Setup ---")

  (foreach item layers
    (setq layName (nth 0 item)
          color   (nth 1 item)
          ltype   (nth 2 item)
          lweight (nth 3 item))

    ;; Create layer if missing
    (if (null (tblsearch "LAYER" layName))
      (command "_.-LAYER" "_M" layName "_C" color layName "_LW" lweight layName ""))
  )

  (princ "\n[Success]: All 14 Standard Survey CAD Layers verified and loaded.")
  (setvar "CMDECHO" 1)
  (princ)
)
(princ "\n[SURVEYPRO] Type SURVLAYERS to initialize Survey Layers.")
(princ)