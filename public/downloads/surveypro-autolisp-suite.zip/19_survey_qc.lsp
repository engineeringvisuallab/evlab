;=========================================================================
;; SURVEYPRO SUITE - TOOL 19: SURVEYQC.LSP
;; Purpose: Comprehensive Survey CAD Drawing Audit and QC Report
;; Author: SurveyPro Cad Systems (c) 2026
;;=========================================================================

(defun c:SURVEYQC ( / *error* ssLines ssPline ssText cnt zeroLen unclosed layer0Cnt i ent obj p1 p2 isClosed)
  (vl-load-com)

  (defun *error* (msg)
    (if (and msg (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*")))
      (princ (strcat "\n[SURVEYQC Error]: " msg)))
    (setvar "CMDECHO" 1)
    (princ)
  )

  (setvar "CMDECHO" 0)

  (princ "\n--- [SURVEYPRO] Survey Drawing QC & Audit ---")
  (setq zeroLen 0 unclosed 0 layer0Cnt 0)

  ;; 1. Check zero length lines
  (setq ssLines (ssget "X" '((0 . "LINE"))))
  (if ssLines
    (progn
      (setq cnt (sslength ssLines) i 0)
      (while (< i cnt)
        (setq ent (ssname ssLines i))
        (setq p1 (cdr (assoc 10 (entget ent))))
        (setq p2 (cdr (assoc 11 (entget ent))))
        (if (< (distance p1 p2) 0.0001)
          (setq zeroLen (1+ zeroLen)))
        (if (= (cdr (assoc 8 (entget ent))) "0")
          (setq layer0Cnt (1+ layer0Cnt)))
        (setq i (1+ i))
      )
    )
  )

  ;; 2. Check unclosed boundary polylines
  (setq ssPline (ssget "X" '((0 . "*POLYLINE") (8 . "*BNDRY*,*BOUNDARY*"))))
  (if ssPline
    (progn
      (setq cnt (sslength ssPline) i 0)
      (while (< i cnt)
        (setq ent (ssname ssPline i))
        (setq obj (vlax-ename->vla-object ent))
        (setq isClosed (vlax-get-property obj 'Closed))
        (if (= isClosed :vlax-false)
          (setq unclosed (1+ unclosed)))
        (setq i (1+ i))
      )
    )
  )

  (princ "\n==================================================")
  (princ "\n SURVEYPRO DRAWING QUALITY AUDIT RESULTS")
  (princ "\n==================================================")
  (princ (strcat "\n Zero-length lines found        : " (itoa zeroLen)))
  (princ (strcat "\n Unclosed boundary polylines   : " (itoa unclosed)))
  (princ (strcat "\n Entities on non-standard Layer 0: " (itoa layer0Cnt)))
  (princ "\n==================================================")
  (if (and (= zeroLen 0) (= unclosed 0) (= layer0Cnt 0))
    (princ "\n[EXCELLENT]: Drawing meets all Survey QC Standards!")
    (princ "\n[ACTION REQUIRED]: Review flagged items before final submission."))

  (setvar "CMDECHO" 1)
  (princ)
)
(princ "\n[SURVEYPRO] Type SURVEYQC to run Drawing QC.")
(princ)