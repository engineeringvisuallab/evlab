;=========================================================================
;; SURVEYPRO SUITE - TOOL 01: AUTOLABEL.LSP
;; Purpose: Automatically label survey points with PNo, E, N, and Elevation
;; Author: SurveyPro Cad Systems (c) 2026
;;=========================================================================

(defun c:AUTOLABEL ( / *error* ss cnt i ent pt x y z pno ht off lay fmt entData)
  (vl-load-com)
  
  ;; Error Handler
  (defun *error* (msg)
    (if (and msg (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*")))
      (princ (strcat "\n[AUTOLABEL Error]: " msg))
    )
    (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
    (setvar "CMDECHO" 1)
    (princ)
  )

  (setvar "CMDECHO" 0)
  (vla-StartUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))

  (princ "\n--- [SURVEYPRO] Survey Point Auto Labeler ---")
  (setq ss (ssget '((0 . "POINT"))))
  
  (if (not ss)
    (princ "\nNo AutoCAD POINT entities selected.")
    (progn
      ;; User Prompt Defaults
      (initget "P PZ PENZ ALL")
      (setq fmt (getkword "\nLabel Format [Point-only(P) / Pno+Z(PZ) / Pno+E+N+Z(PENZ) / ALL(ALL)] <PZ>: "))
      (if (null fmt) (setq fmt "PZ"))

      (setq ht (getdist "\nSpecify Text Height <1.50>: "))
      (if (null ht) (setq ht 1.50))

      (setq off (getdist "\nSpecify Text Offset from point <1.20>: "))
      (if (null off) (setq off 1.20))

      (setq pno (getint "\nStarting Point Number <1>: "))
      (if (null pno) (setq pno 1))

      ;; Ensure target layers exist
      (if (null (tblsearch "LAYER" "SURV-PNO"))
        (command "_.-LAYER" "_M" "SURV-PNO" "_C" "4" "" "")
      )
      (if (null (tblsearch "LAYER" "SURV-ELEV"))
        (command "_.-LAYER" "_M" "SURV-ELEV" "_C" "3" "" "")
      )

      (setq cnt (sslength ss)
            i 0)
      
      (princ (strcat "\nProcessing " (itoa cnt) " survey points..."))

      (while (< i cnt)
        (setq ent (ssname ss i))
        (setq entData (entget ent))
        (setq pt (cdr (assoc 10 entData))) ; (X Y Z)
        (setq x (car pt)
              y (cadr pt)
              z (caddr pt))
        
        ;; Label Insertion Point (offset by 45 degrees to avoid direct overlap)
        (setq insPt (list (+ x off) (+ y off) z))
        (setq elevInsPt (list (+ x off) (- (+ y off) (* ht 1.3)) z))

        ;; Generate entities based on format
        (cond
          ((= fmt "P")
           (entmake (list '(0 . "TEXT")
                          '(100 . "AcDbEntity")
                          '(8 . "SURV-PNO")
                          '(100 . "AcDbText")
                          (cons 10 insPt)
                          (cons 40 ht)
                          (cons 1 (itoa pno))
                          '(72 . 0)
                          '(73 . 0))))
          
          ((= fmt "PZ")
           (entmake (list '(0 . "TEXT")
                          '(100 . "AcDbEntity")
                          '(8 . "SURV-PNO")
                          '(100 . "AcDbText")
                          (cons 10 insPt)
                          (cons 40 ht)
                          (cons 1 (strcat "P" (itoa pno)))
                          '(72 . 0)))
           (entmake (list '(0 . "TEXT")
                          '(100 . "AcDbEntity")
                          '(8 . "SURV-ELEV")
                          '(100 . "AcDbText")
                          (cons 10 elevInsPt)
                          (cons 40 (* ht 0.9))
                          (cons 1 (rtos z 2 3))
                          '(72 . 0))))

          ((or (= fmt "PENZ") (= fmt "ALL"))
           (setq mtextStr (strcat "{\\C4;P" (itoa pno) "}\P"
                                  "{\\C2;E: " (rtos x 2 3) "}\P"
                                  "{\\C2;N: " (rtos y 2 3) "}\P"
                                  "{\\C3;Z: " (rtos z 2 3) "}"))
           (entmake (list '(0 . "MTEXT")
                          '(100 . "AcDbEntity")
                          '(8 . "SURV-PNO")
                          '(100 . "AcDbMText")
                          (cons 10 insPt)
                          (cons 40 ht)
                          '(71 . 1) ; Top-Left
                          (cons 1 mtextStr)))))

        (setq pno (1+ pno))
        (setq i (1+ i))
      )
      (princ (strcat "\n[Success]: " (itoa cnt) " survey points labeled."))
    )
  )

  (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setvar "CMDECHO" 1)
  (princ)
)
(princ "\n[SURVEYPRO] Type AUTOLABEL to run Point Auto Labeler.")
(princ)