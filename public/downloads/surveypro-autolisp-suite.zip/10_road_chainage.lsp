;=========================================================================
;; SURVEYPRO SUITE - TOOL 10: ROADCH.LSP
;; Purpose: Road Alignment Chainage Stationing & Tick Mark Generator
;; Author: SurveyPro Cad Systems (c) 2026
;;=========================================================================

(defun c:ROADCH ( / *error* ent obj len intVal startCh curCh curDist pt deriv ang perpAng tickLen tickP1 tickP2 txtPt km m remM chStr ht)
  (vl-load-com)

  (defun *error* (msg)
    (if (and msg (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*")))
      (princ (strcat "\n[ROADCH Error]: " msg)))
    (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
    (setvar "CMDECHO" 1)
    (princ)
  )

  (setvar "CMDECHO" 0)
  (vla-StartUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))

  ;; Format Chainage Helper: 1240 -> "CH 1+240.00"
  (defun format-chainage (val / km m kmStr mStr)
    (setq km (fix (/ val 1000.0)))
    (setq m (- val (* km 1000.0)))
    (setq kmStr (itoa km))
    (if (< m 10.0)
      (setq mStr (strcat "00" (rtos m 2 2)))
      (if (< m 100.0)
        (setq mStr (strcat "0" (rtos m 2 2)))
        (setq mStr (rtos m 2 2))))
    (strcat "CH " kmStr "+" mStr)
  )

  (princ "\n--- [SURVEYPRO] Road Alignment Chainage Generator ---")
  (setq ent (car (entsel "\nSelect Road Centerline Polyline: ")))

  (if ent
    (progn
      (setq obj (vlax-ename->vla-object ent))
      (setq len (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj)))
      (princ (strcat "\nTotal Alignment Length: " (rtos len 2 3) " m"))

      (setq intVal (getdist "\nSpecify Chainage Interval <20.00>: "))
      (if (null intVal) (setq intVal 20.00))

      (setq startCh (getreal "\nSpecify Starting Chainage <0.00>: "))
      (if (null startCh) (setq startCh 0.00))

      (setq ht (getdist "\nSpecify Text Height <1.50>: "))
      (if (null ht) (setq ht 1.50))
      (setq tickLen (* ht 1.5))

      ;; Create Layer
      (if (null (tblsearch "LAYER" "SURV-CHAINAGE"))
        (command "_.-LAYER" "_M" "SURV-CHAINAGE" "_C" "1" "" ""))

      (setq curDist 0.0)
      (while (<= curDist len)
        (setq curCh (+ startCh curDist))
        (setq pt (vlax-curve-getPointAtDist obj curDist))
        (setq deriv (vlax-curve-getFirstDeriv obj (vlax-curve-getParamAtDist obj curDist)))
        (setq ang (angle '(0 0 0) deriv))
        (setq perpAng (+ ang (/ pi 2.0)))

        ;; Tick Mark Points
        (setq tickP1 (list (+ (car pt) (* (/ tickLen 2.0) (cos perpAng)))
                           (+ (cadr pt) (* (/ tickLen 2.0) (sin perpAng)))
                           (caddr pt)))
        (setq tickP2 (list (- (car pt) (* (/ tickLen 2.0) (cos perpAng)))
                           (- (cadr pt) (* (/ tickLen 2.0) (sin perpAng)))
                           (caddr pt)))

        ;; Draw Tick Line
        (entmake (list '(0 . "LINE")
                       '(100 . "AcDbEntity")
                       '(8 . "SURV-CHAINAGE")
                       '(100 . "AcDbLine")
                       (cons 10 tickP1)
                       (cons 11 tickP2)))

        ;; Label insertion point
        (setq txtPt (list (+ (car pt) (* (* tickLen 1.2) (cos perpAng)))
                          (+ (cadr pt) (* (* tickLen 1.2) (sin perpAng)))
                          (caddr pt)))

        ;; Readability angle
        (setq txtAng perpAng)
        (if (or (> txtAng (/ pi 2.0)) (< txtAng (- (/ pi 2.0))))
          (setq txtAng (+ txtAng pi)))

        (setq chStr (format-chainage curCh))
        (entmake (list '(0 . "TEXT")
                       '(100 . "AcDbEntity")
                       '(8 . "SURV-CHAINAGE")
                       '(100 . "AcDbText")
                       (cons 10 txtPt)
                       (cons 40 ht)
                       (cons 1 chStr)
                       (cons 50 txtAng)
                       '(72 . 0)))

        (setq curDist (+ curDist intVal))
      )
      (princ (strcat "\n[Success]: Chainage generated up to " (format-chainage (+ startCh len))))
    )
    (princ "\nNo alignment polyline selected.")
  )

  (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setvar "CMDECHO" 1)
  (princ)
)
(princ "\n[SURVEYPRO] Type ROADCH to run Road Chainage Generator.")
(princ)