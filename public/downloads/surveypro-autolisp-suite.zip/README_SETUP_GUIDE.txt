================================================================================
          SURVEYPRO CAD SUITE 2026 - AUTOCAD INSTALLATION & USER MANUAL
================================================================================

1. QUICK START (APPLOAD METHOD):
--------------------------------------------------------------------------------
1. Open AutoCAD (Compatible with AutoCAD 2018-2027, Civil 3D, NanoCAD, BricsCAD).
2. Type 'APPLOAD' in the AutoCAD command line and press ENTER.
3. Browse and select 'surveypro.lsp' (or any individual tool .lsp file).
4. Click 'Load' (and optionally 'Add to Startup Suite' briefcase icon so it loads automatically on startup).
5. In the AutoCAD command line, type:
   Command: SURVEYPRO
   and press ENTER to launch the master menu!

2. DRAG AND DROP:
--------------------------------------------------------------------------------
You can also simply drag and drop 'surveypro.lsp' directly from Windows File Explorer
into any open AutoCAD drawing window!

3. COMMAND DIRECTORY:
--------------------------------------------------------------------------------
Command       Description
--------------------------------------------------------------------------------
AUTOLABEL     Auto label selected survey points with PNo, E, N, Z
XYZ2PT        Create 3D Points from pasted coordinates (E,N,Z or P,E,N,Z)
CSV2SURV      Import survey points from CSV/TXT with layered text
SPOTLVL       Auto spot level & RL generator (prefix e.g. RL=)
CONTOURPREP   Contour preparation & TIN range analysis
CONTOURLBL    Auto label contour curves with elevation along tangents
TRAVERSE      Closed traverse solver with Bowditch coordinate adjustment
SURVBD        Bearing & Distance from 2 points (HD, SD, DMS Azimuth, dE, dN)
SURVDIM       Auto aligned dimension survey boundary linework
ROADCH        Road centerline chainage stationing (CH 0+000, CH 0+020)
CHOFFSET      Calculate chainage and left/right offsets of survey points
XSECTION      Cross section ground profile drawing generator
LPROFILE      Longitudinal profile & grid plotter
BNDRYINFO     Boundary parcel area (sq.m, Ha, Acres) & vertex table
COORDTBL      Generate professional AutoCAD TABLE from survey points
RENUMBERPT    Batch spatial point renumbering (LR, RL, TB, BT)
QCPOINTS      Scan duplicate coordinates, zero elevations & outliers
SURVLAYERS    Initialize 14 standard survey CAD layers
SURVEYQC      Deep drawing quality compliance audit & cleanup
SURVEYPRO     Master all-in-one menu running all tools

================================================================================
(c) 2026 SurveyPro Engineering CAD Systems. All Rights Reserved.
================================================================================