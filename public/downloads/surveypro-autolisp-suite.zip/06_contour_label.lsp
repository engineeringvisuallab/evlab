;=========================================================================
;; SURVEYPRO SUITE - TOOL 06: CONTOURLBL.LSP
;; Purpose: Automatically label contour polylines with elevation text
;; Author: SurveyPro Cad Systems (c) 2026
;;=========================================================================

(defun c:CONTOURLBL ( / *error* ss cnt i ent obj elev len interval ht curDist pt ang angDeg str)
  (vl-load-com)

  (defun *error* (msg)
    (if (and msg (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*")))
      (princ (strcat "\n[CONTOURLBL Error]: " msg)))
    (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
    (setvar "CMDECHO" 1)
    (princ)
  )

  (setvar "CMDECHO" 0)
  (vla-StartUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))

  (princ "\n--- [SURVEYPRO] Contour Auto Labeler ---")
  (setq ss (ssget '((0 . "*POLYLINE,LINE"))))

  (if ss
    (progn
      (setq ht (getdist "\nSpecify text height <1.20>: "))
      (if (null ht) (setq ht 1.20))

      (setq interval (getdist "\nSpecify distance interval between labels along curve <50.0>: "))
      (if (null interval) (setq interval 50.0))

      (if (null (tblsearch "LAYER" "SURV-ANNO"))
        (command "_.-LAYER" "_M" "SURV-ANNO" "_C" "7" "" ""))

      (setq cnt (sslength ss) i 0)
      (while (< i cnt)
        (setq ent (ssname ss i))
        (setq obj (vlax-ename->vla-object ent))
        
        ;; Extract elevation
        (setq elev (vl-catch-all-apply 'vla-get-Elevation (list obj)))
        (if (vl-catch-all-error-p elev)
          (setq elev (caddr (vlax-curve-getStartPoint obj))))
        
        (if (numberp elev)
          (progn
            (setq len (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj)))
            (setq curDist (/ interval 2.0)) ; Start at half interval
            (setq str (rtos elev 2 1))

            (while (< curDist len)
              (setq pt (vlax-curve-getPointAtDist obj curDist))
              (setq ang (angle '(0 0 0) (vlax-curve-getFirstDeriv obj (vlax-curve-getParamAtDist obj curDist))))
              
              ;; Ensure text is readable (not upside down)
              (if (or (> ang (/ pi 2.0)) (< ang (- (/ pi 2.0))))
                (setq ang (+ ang pi)))
              (setq angDeg (* (/ ang pi) 180.0))

              (entmake (list '(0 . "TEXT")
                             '(100 . "AcDbEntity")
                             '(8 . "SURV-ANNO")
                             '(100 . "AcDbText")
                             (cons 10 pt)
                             (cons 40 ht)
                             (cons 1 str)
                             (cons 50 ang)
                             '(72 . 1) ; Center aligned
                             '(73 . 2) ; Middle aligned
                             (cons 11 pt)))

              (setq curDist (+ curDist interval))
            )
          )
        )
        (setq i (1+ i))
      )
      (princ (strcat "\n[Success]: Labeled contours along " (itoa cnt) " polyline segments."))
    )
    (princ "\nNo contour polylines selected.")
  )

  (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setvar "CMDECHO" 1)
  (princ)
)
(princ "\n[SURVEYPRO] Type CONTOURLBL to run Contour Labeler.")
(princ)