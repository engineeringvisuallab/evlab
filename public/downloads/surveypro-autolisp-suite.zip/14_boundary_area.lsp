;=========================================================================
;; SURVEYPRO SUITE - TOOL 14: BNDRYINFO.LSP
;; Purpose: Boundary Parcel Analysis, Area/Perimeter & Vertex Table
;; Author: SurveyPro Cad Systems (c) 2026
;;=========================================================================

(defun c:BNDRYINFO ( / *error* ent obj area perim ha acres n i pt insPt areaStr)
  (vl-load-com)

  (defun *error* (msg)
    (if (and msg (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*")))
      (princ (strcat "\n[BNDRYINFO Error]: " msg)))
    (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
    (setvar "CMDECHO" 1)
    (princ)
  )

  (setvar "CMDECHO" 0)
  (vla-StartUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))

  (princ "\n--- [SURVEYPRO] Boundary Area & Parcel Analysis ---")
  (setq ent (car (entsel "\nSelect Closed Parcel Boundary Polyline: ")))

  (if ent
    (progn
      (setq obj (vlax-ename->vla-object ent))
      (setq area (vlax-get-property obj 'Area))
      (setq perim (vlax-curve-getDistAtParam obj (vlax-curve-getEndParam obj)))
      (setq ha (/ area 10000.0))
      (setq acres (* area 0.000247105))

      (princ "\n==========================================")
      (princ (strcat "\n Parcel Area       : " (rtos area 2 2) " sq.m"))
      (princ (strcat "\n Area in Hectares  : " (rtos ha 2 4) " Ha"))
      (princ (strcat "\n Area in Acres     : " (rtos acres 2 3) " Acres"))
      (princ (strcat "\n Perimeter Length  : " (rtos perim 2 3) " m"))
      (princ "\n==========================================")

      (setq insPt (getpoint "\nPick point inside plot to place area label: "))
      (if insPt
        (progn
          (if (null (tblsearch "LAYER" "SURV-ANNO"))
            (command "_.-LAYER" "_M" "SURV-ANNO" "_C" "7" "" ""))
          
          (setq areaStr (strcat "{\\C7;AREA: " (rtos area 2 2) " Sq.m (" (rtos ha 2 3) " Ha)}\P"
                                "{\\C3;PERIMETER: " (rtos perim 2 2) " m}"))
          
          (entmake (list '(0 . "MTEXT")
                         '(100 . "AcDbEntity")
                         '(8 . "SURV-ANNO")
                         '(100 . "AcDbMText")
                         (cons 10 insPt)
                         (cons 40 1.8)
                         '(71 . 5) ; Middle Center
                         (cons 1 areaStr)))
          (princ "\nArea label placed.")
        )
      )
    )
    (princ "\nNo boundary entity selected.")
  )

  (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setvar "CMDECHO" 1)
  (princ)
)
(princ "\n[SURVEYPRO] Type BNDRYINFO to run Boundary Analysis.")
(princ)