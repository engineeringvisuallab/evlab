;=========================================================================
;; SURVEYPRO SUITE - TOOL 04: SPOTLVL.LSP
;; Purpose: Auto Spot Level and Reduced Level (RL) Annotation Generator
;; Author: SurveyPro Cad Systems (c) 2026
;;=========================================================================

(defun c:SPOTLVL ( / *error* ss cnt i ent pt z prefix prec ht off insPt str)
  (vl-load-com)

  (defun *error* (msg)
    (if (and msg (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*")))
      (princ (strcat "\n[SPOTLVL Error]: " msg)))
    (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
    (setvar "CMDECHO" 1)
    (princ)
  )

  (setvar "CMDECHO" 0)
  (vla-StartUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))

  (princ "\n--- [SURVEYPRO] Auto Spot Level Generator ---")
  (setq ss (ssget '((0 . "POINT"))))

  (if ss
    (progn
      (setq prefix (getstring T "\nEnter Spot Level Prefix (e.g. RL=, +, EL:) <RL=>: "))
      (if (= prefix "") (setq prefix "RL="))

      (setq prec (getint "\nDecimal precision (2 or 3) <3>: "))
      (if (null prec) (setq prec 3))

      (setq ht (getdist "\nSpecify text height <1.00>: "))
      (if (null ht) (setq ht 1.00))

      (setq off (getdist "\nSpecify label offset <0.80>: "))
      (if (null off) (setq off 0.80))

      (if (null (tblsearch "LAYER" "SURV-ELEV"))
        (command "_.-LAYER" "_M" "SURV-ELEV" "_C" "3" "" ""))

      (setq cnt (sslength ss) i 0)
      (while (< i cnt)
        (setq ent (ssname ss i))
        (setq pt (cdr (assoc 10 (entget ent))))
        (setq z (caddr pt))
        (setq insPt (list (+ (car pt) off) (+ (cadr pt) off) z))
        (setq str (strcat prefix (rtos z 2 prec)))

        (entmake (list '(0 . "TEXT")
                       '(100 . "AcDbEntity")
                       '(8 . "SURV-ELEV")
                       '(100 . "AcDbText")
                       (cons 10 insPt)
                       (cons 40 ht)
                       (cons 1 str)
                       '(72 . 0)))
        (setq i (1+ i))
      )
      (princ (strcat "\n[Success]: Placed " (itoa cnt) " spot level annotations."))
    )
    (princ "\nNo points selected.")
  )

  (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setvar "CMDECHO" 1)
  (princ)
)
(princ "\n[SURVEYPRO] Type SPOTLVL to run Spot Level Generator.")
(princ)