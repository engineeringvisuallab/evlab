// SURVEYPRO DCL Dialog Definition
surveypro_dialog : dialog {
  label = "SurveyPro CAD Suite 2026";
  
  : boxed_column {
    label = "Point & Field Data Tools";
    : row {
      : button { key = "btn_csv"; label = "1. CSV Survey Importer"; width = 28; }
      : button { key = "btn_xyz"; label = "2. Coord -> 3D Point"; width = 28; }
    }
    : row {
      : button { key = "btn_autolabel"; label = "3. Auto Point Labels"; width = 28; }
      : button { key = "btn_spot"; label = "4. Auto Spot Levels (RL)"; width = 28; }
    }
    : row {
      : button { key = "btn_renumber"; label = "5. Point Renumbering"; width = 28; }
      : button { key = "btn_table"; label = "6. Coordinate Table"; width = 28; }
    }
  }

  : boxed_column {
    label = "Traverse & Topography";
    : row {
      : button { key = "btn_traverse"; label = "7. Bowditch Traverse"; width = 28; }
      : button { key = "btn_bd"; label = "8. Bearing & Distance"; width = 28; }
    }
    : row {
      : button { key = "btn_contourprep"; label = "9. Contour Prep & TIN"; width = 28; }
      : button { key = "btn_contourlbl"; label = "10. Contour Elevation Label"; width = 28; }
    }
  }

  : boxed_column {
    label = "Road Alignment & Corridor";
    : row {
      : button { key = "btn_chainage"; label = "11. Centerline Chainage"; width = 28; }
      : button { key = "btn_offset"; label = "12. Station + Offset Calc"; width = 28; }
    }
    : row {
      : button { key = "btn_xsection"; label = "13. Cross Section Generator"; width = 28; }
      : button { key = "btn_profile"; label = "14. Longitudinal Profile"; width = 28; }
    }
  }

  : boxed_column {
    label = "Quality Control & Boundary";
    : row {
      : button { key = "btn_boundary"; label = "15. Boundary Area/Perim"; width = 28; }
      : button { key = "btn_dim"; label = "16. Auto Dimensions"; width = 28; }
    }
    : row {
      : button { key = "btn_qc"; label = "17. Duplicate Point Check"; width = 28; }
      : button { key = "btn_drawqc"; label = "18. Drawing Cleanup QC"; width = 28; }
    }
    : row {
      : button { key = "btn_layers"; label = "19. Standard Layer Manager"; width = 28; }
      : button { key = "btn_all"; label = "20. Complete Run"; width = 28; }
    }
  }

  ok_cancel;
}