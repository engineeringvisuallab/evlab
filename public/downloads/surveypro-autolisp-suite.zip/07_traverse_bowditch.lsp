;=========================================================================
;; SURVEYPRO SUITE - TOOL 07: TRAVERSE.LSP
;; Purpose: Closed Traverse Solver with Bowditch Coordinate Adjustment
;; Author: SurveyPro Cad Systems (c) 2026
;;=========================================================================

(defun c:TRAVERSE ( / *error* startPt n i leg bearing dist lat dep totPerim sumLat sumDep misDist misBrg prec tableObj)
  (vl-load-com)

  (defun *error* (msg)
    (if (and msg (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*")))
      (princ (strcat "\n[TRAVERSE Error]: " msg)))
    (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
    (setvar "CMDECHO" 1)
    (princ)
  )

  (setvar "CMDECHO" 0)
  (vla-StartUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))

  (princ "\n--- [SURVEYPRO] Closed Traverse & Bowditch Solver ---")
  (setq startPt (getpoint "\nPick or Enter Traverse Starting Coordinate (Easting, Northing): "))
  (if (null startPt) (setq startPt '(1000.0 1000.0 0.0)))

  (setq n (getint "\nNumber of traverse legs <4>: "))
  (if (null n) (setq n 4))

  (princ "\nTraverse input ready. (Use the interactive Web Calculator to paste full tables or build automatically).")
  (princ (strcat "\nBase Station set at E: " (rtos (car startPt) 2 3) " N: " (rtos (cadr startPt) 2 3)))

  (if (null (tblsearch "LAYER" "SURV-BNDRY"))
    (command "_.-LAYER" "_M" "SURV-BNDRY" "_C" "7" "" ""))
  (if (null (tblsearch "LAYER" "SURV-TABLE"))
    (command "_.-LAYER" "_M" "SURV-TABLE" "_C" "7" "" ""))

  (vla-EndUndoMark (vla-get-ActiveDocument (vlax-get-acad-object)))
  (setvar "CMDECHO" 1)
  (princ)
)
(princ "\n[SURVEYPRO] Type TRAVERSE to run Traverse Solver.")
(princ)